# VendorBridge

**Enterprise Procurement & Vendor Management ERP System**

VendorBridge is a modern, full-stack procurement platform built with React, Node.js, and PostgreSQL. It streamlines vendor management, RFQ processes, quotation comparisons, multi-level approvals, purchase orders, and invoice generation.

---

## 🏗️ Architecture

```
vendorbridge/
├── packages/
│   └── shared/              # Zod schemas + TypeScript types (shared)
├── apps/
│   ├── server/              # Express + Prisma backend
│   └── client/              # React + Vite frontend
├── docker-compose.yml       # PostgreSQL + Redis
└── pnpm-workspace.yaml      # Monorepo config
```

### Tech Stack

**Frontend**
- React 18 + TypeScript
- TanStack Query v5 (data fetching)
- Zustand (state management)
- shadcn/ui (UI components)
- React Router v6
- Socket.IO Client
- Recharts (analytics)

**Backend**
- Node.js + Express
- Prisma ORM
- PostgreSQL 16
- Redis (caching + queues)
- Socket.IO (real-time)
- Bull (job queue)
- Puppeteer (PDF generation)

**Advanced**
- Anthropic Claude API (AI assistant)
- Ethers.js + Hardhat (blockchain)
- JWT + refresh tokens (auth)

---

## ✨ New Super Cool Features!

### 🤖 AI-Powered Chatbot
- **Smart procurement assistant** powered by Claude
- Context-aware responses based on your role
- Vendor analysis and recommendations
- Cost optimization insights
- Beautiful gradient UI with animations
- **Try it:** Click the purple chat bubble in bottom-right corner!

### ⛓️ Blockchain Verification
- **Immutable document anchoring** on Polygon blockchain
- SHA-256 cryptographic hashing
- Tamper-proof audit trails
- Transaction verification on blockchain explorer
- Professional verification badges
- **Try it:** Go to Purchase Orders → Click "Anchor to Blockchain"!

### 🎨 Beautiful Modern UI
- Purple-to-Blue gradient themes
- Smooth animations and transitions
- Responsive design
- Professional toast notifications

---

## 🚀 Features

### Core Functionality
- **Vendor Management** - Register, verify, and manage vendor profiles with ratings
- **RFQ System** - Create and publish Request for Quotations with item specifications
- **Quotation Handling** - Vendors submit quotations; procurement officers compare bids
- **Approval Workflows** - Multi-level approval system with role-based access
- **Purchase Orders** - Generate POs with blockchain audit trail
- **Invoice Management** - PDF generation, email delivery, payment tracking
- **Activity Logs** - Comprehensive audit trail for all operations
- **Analytics Dashboard** - Real-time insights and reports

### Advanced Features
- **Real-time Notifications** - Socket.IO powered live updates
- **AI Assistant** - Claude-powered procurement assistant
- **Blockchain Audit** - Immutable document anchoring on Polygon
- **Background Jobs** - Bull queue for PDF generation and email delivery
- **Multi-tenant Ready** - Organization-level data isolation

---

## 📋 Prerequisites

- Node.js >= 20.0.0
- pnpm >= 8.0.0
- Docker & Docker Compose
- PostgreSQL 16 (via Docker)
- Redis 7 (via Docker)

---

## 🛠️ Quick Start

### 1. Clone the Repository

```bash
git clone https://github.com/your-org/vendorbridge.git
cd vendorbridge
```

### 2. Install Dependencies

```bash
pnpm install
```

### 3. Start Infrastructure

```bash
# Start PostgreSQL + Redis
docker-compose up -d

# Verify services are running
docker-compose ps
```

### 4. Set Up Environment Variables

```bash
# Server environment
cp apps/server/.env.example apps/server/.env
# Edit apps/server/.env with your configuration

# Client environment
cp apps/client/.env.example apps/client/.env
```

### 5. Set Up Database

```bash
# Generate Prisma client
cd apps/server
pnpm prisma generate

# Run migrations
pnpm prisma migrate dev

# Seed database with demo data
pnpm prisma db seed

# (Optional) Open Prisma Studio
pnpm prisma studio
```

### 6. Start Development Servers

```bash
# From root directory
pnpm dev

# Or run individually:
# Backend: cd apps/server && pnpm dev
# Frontend: cd apps/client && pnpm dev
```

**Access the application:**
- Frontend: http://localhost:3000
- Backend API: http://localhost:4000
- Prisma Studio: http://localhost:5555

---

## 👥 Default Users (After Seeding)

| Role | Email | Password |
|------|-------|----------|
| Admin | admin@vendorbridge.com | admin123 |
| Procurement Officer | procurement@vendorbridge.com | procurement123 |
| Manager | manager@vendorbridge.com | manager123 |
| Vendor | vendor1@example.com | vendor123 |

---

## 📂 Project Structure

### Backend Modules (`apps/server/src/modules/`)

Each module follows the pattern:
```
module-name/
├── module-name.controller.ts    # Request handlers
├── module-name.service.ts       # Business logic
├── module-name.routes.ts        # Route definitions
└── module-name.types.ts         # Module-specific types
```

**Available Modules:**
- `auth` - Authentication & authorization
- `vendors` - Vendor CRUD + verification
- `rfq` - Request for Quotation management
- `quotations` - Quotation submission + comparison
- `approvals` - Multi-level approval workflows
- `purchase-orders` - PO generation + blockchain anchoring
- `invoices` - Invoice generation, PDF, email
- `activity-logs` - Audit trail
- `reports` - Analytics and reporting
- `ai-assistant` - Claude-powered assistant
- `blockchain` - Document anchoring

### Frontend Features (`apps/client/src/features/`)

Each feature follows the pattern:
```
feature-name/
├── api/                  # TanStack Query hooks
├── components/           # Feature-specific components
├── hooks/                # Feature-specific hooks
├── types.ts              # Feature types
└── index.ts              # Public exports
```

---

## 🔧 Available Scripts

### Root

```bash
pnpm dev              # Start all services in development mode
pnpm build            # Build all packages
pnpm lint             # Lint all packages
pnpm test             # Run all tests
pnpm clean            # Clean all build artifacts

pnpm docker:up        # Start Docker services
pnpm docker:down      # Stop Docker services

pnpm prisma:generate  # Generate Prisma client
pnpm prisma:migrate   # Run database migrations
pnpm prisma:studio    # Open Prisma Studio
pnpm prisma:seed      # Seed database
```

### Server (`apps/server`)

```bash
pnpm dev              # Start dev server with watch mode
pnpm build            # Build TypeScript
pnpm start            # Start production server
pnpm lint             # Lint server code
```

### Client (`apps/client`)

```bash
pnpm dev              # Start Vite dev server
pnpm build            # Build for production
pnpm preview          # Preview production build
pnpm lint             # Lint client code
```

---

## 🔐 Environment Variables

### Server (`apps/server/.env`)

See `apps/server/.env.example` for all variables:
- `DATABASE_URL` - PostgreSQL connection string
- `REDIS_URL` - Redis connection string
- `JWT_SECRET` / `JWT_REFRESH_SECRET` - Authentication secrets
- `SMTP_*` - Email configuration
- `ANTHROPIC_API_KEY` - Claude API key
- `RPC_URL` / `BLOCKCHAIN_PRIVATE_KEY` - Blockchain config

### Client (`apps/client/.env`)

- `VITE_API_URL` - Backend API URL
- `VITE_SOCKET_URL` - Socket.IO server URL

---

## 🧪 Testing

```bash
# Run all tests
pnpm test

# Run tests for specific package
cd apps/server && pnpm test
cd apps/client && pnpm test
```

---

## 🚢 Deployment

### Production Build

```bash
# Build all packages
pnpm build

# Output:
# - apps/server/dist/     (Node.js backend)
# - apps/client/dist/     (Static frontend)
```

### Environment Setup

1. Set up PostgreSQL and Redis instances
2. Configure environment variables for production
3. Run Prisma migrations: `pnpm prisma migrate deploy`
4. Start backend: `cd apps/server && pnpm start`
5. Serve frontend build with nginx/CDN

---

## 📖 Documentation

- [Implementation Guide](./VENDORBRIDGE_IMPLEMENTATION.md) - Complete implementation patterns
- [Project Restructure](./PROJECT_RESTRUCTURE.md) - Architecture overview
- [API Documentation](./docs/API.md) - REST API reference *(to be created)*
- [Database Schema](./apps/server/prisma/schema.prisma) - Prisma schema

---

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/my-feature`
3. Commit changes: `git commit -m 'Add my feature'`
4. Push to branch: `git push origin feature/my-feature`
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

---

## 🙏 Acknowledgments

- Built with modern best practices for enterprise applications
- Follows modular architecture for scalability
- Designed for multi-tenant SaaS deployment

---

**VendorBridge** - Streamlining Procurement, One RFQ at a Time
