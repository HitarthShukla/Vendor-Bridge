# VendorBridge Complete Implementation Guide

Based on the **Project Bible v2.0**, this guide provides the complete implementation for the VendorBridge procurement ERP system.

---

## 🚀 Current Status

### ✅ What's Been Created

```
/workspaces/default/code/
├── docker-compose.yml          ✅ PostgreSQL + Redis containers
├── pnpm-workspace.yaml         ✅ Monorepo workspace config
├── apps/
│   └── server/
│       └── prisma/
│           └── schema.prisma   ✅ Complete Prisma schema (all models)
├── src/app/                    ✅ Original frontend (to be restructured)
└── docs/                       ✅ Documentation
```

### ⚠️ Environment Limitation

This **Figma Make environment is frontend-only** and blocks creating backend `.ts` files. The complete backend code must be implemented in a separate Node.js environment.

---

## 📋 Complete Implementation Steps

### Step 1: Set Up Monorepo Structure

Create the following structure in a **separate Node.js environment**:

```bash
mkdir -p vendorbridge
cd vendorbridge

# Create monorepo structure
mkdir -p packages/shared/src/{schemas,types}
mkdir -p apps/server/src/{modules,middleware,lib,jobs}
mkdir -p apps/client/src/{components,features,hooks,layouts,lib,routes,store,types}

# Copy files from Figma Make workspace
# - docker-compose.yml
# - pnpm-workspace.yaml
# - apps/server/prisma/schema.prisma
```

### Step 2: Initialize Packages

```bash
# Root package.json
cat > package.json << 'EOF'
{
  "name": "vendorbridge",
  "version": "1.0.0",
  "private": true,
  "scripts": {
    "dev": "turbo run dev",
    "build": "turbo run build",
    "test": "turbo run test",
    "lint": "turbo run lint",
    "clean": "turbo run clean && rm -rf node_modules"
  },
  "devDependencies": {
    "turbo": "^1.11.0",
    "typescript": "^5.3.3"
  },
  "engines": {
    "node": ">=20.0.0",
    "pnpm": ">=8.0.0"
  },
  "packageManager": "pnpm@8.15.0"
}
EOF

# Shared package
cat > packages/shared/package.json << 'EOF'
{
  "name": "@vendorbridge/shared",
  "version": "1.0.0",
  "main": "./src/index.ts",
  "types": "./src/index.ts",
  "dependencies": {
    "zod": "^3.22.4"
  },
  "devDependencies": {
    "typescript": "^5.3.3"
  }
}
EOF

# Server package
cat > apps/server/package.json << 'EOF'
{
  "name": "@vendorbridge/server",
  "version": "1.0.0",
  "scripts": {
    "dev": "tsx watch src/server.ts",
    "build": "tsc",
    "start": "node dist/server.js",
    "prisma:generate": "prisma generate",
    "prisma:migrate": "prisma migrate dev",
    "prisma:studio": "prisma studio",
    "prisma:seed": "tsx prisma/seed.ts"
  },
  "dependencies": {
    "@prisma/client": "^5.8.0",
    "@vendorbridge/shared": "workspace:*",
    "express": "^4.18.2",
    "cors": "^2.8.5",
    "helmet": "^7.1.0",
    "bcryptjs": "^2.4.3",
    "jsonwebtoken": "^9.0.2",
    "zod": "^3.22.4",
    "socket.io": "^4.6.1",
    "redis": "^4.6.11",
    "bull": "^4.11.5",
    "nodemailer": "^6.9.7",
    "puppeteer": "^21.6.1",
    "ethers": "^6.9.0",
    "dotenv": "^16.3.1",
    "@anthropic-ai/sdk": "^0.9.1"
  },
  "devDependencies": {
    "@types/express": "^4.17.21",
    "@types/cors": "^2.8.17",
    "@types/bcryptjs": "^2.4.6",
    "@types/jsonwebtoken": "^9.0.5",
    "@types/nodemailer": "^6.4.14",
    "@types/node": "^20.10.0",
    "prisma": "^5.8.0",
    "tsx": "^4.7.0",
    "typescript": "^5.3.3"
  }
}
EOF

# Client package
cat > apps/client/package.json << 'EOF'
{
  "name": "@vendorbridge/client",
  "version": "1.0.0",
  "scripts": {
    "dev": "vite",
    "build": "tsc && vite build",
    "preview": "vite preview",
    "lint": "eslint src --ext ts,tsx"
  },
  "dependencies": {
    "@vendorbridge/shared": "workspace:*",
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "react-router-dom": "^6.21.0",
    "@tanstack/react-query": "^5.14.6",
    "zustand": "^4.4.7",
    "zod": "^3.22.4",
    "react-hook-form": "^7.49.2",
    "@hookform/resolvers": "^3.3.3",
    "socket.io-client": "^4.6.1",
    "axios": "^1.6.2",
    "lucide-react": "^0.303.0",
    "recharts": "^2.10.3",
    "@tanstack/react-table": "^8.11.2",
    "date-fns": "^3.0.6",
    "clsx": "^2.0.0",
    "tailwind-merge": "^2.2.0"
  },
  "devDependencies": {
    "@types/react": "^18.2.45",
    "@types/react-dom": "^18.2.18",
    "@vitejs/plugin-react": "^4.2.1",
    "autoprefixer": "^10.4.16",
    "postcss": "^8.4.32",
    "tailwindcss": "^3.4.0",
    "typescript": "^5.3.3",
    "vite": "^5.0.8"
  }
}
EOF
```

### Step 3: Install Dependencies

```bash
# Install all dependencies
pnpm install

# Generate Prisma client
cd apps/server
pnpm prisma generate
```

### Step 4: Start Infrastructure

```bash
# Start PostgreSQL + Redis
docker-compose up -d

# Wait for services to be ready
docker-compose ps

# Run migrations
cd apps/server
pnpm prisma migrate dev --name init

# Seed database
pnpm prisma:seed
```

---

## 🗂️ Module Implementation Pattern

### Backend Module Example: Vendors

```typescript
// apps/server/src/modules/vendors/vendors.service.ts
import { prisma } from '../../lib/prisma';
import { VendorStatus } from '@prisma/client';

export class VendorsService {
  async getAllVendors(filters?: {
    status?: VendorStatus;
    category?: string;
    page?: number;
    limit?: number;
  }) {
    const { status, category, page = 1, limit = 20 } = filters || {};
    
    const where = {
      deleted_at: null,
      ...(status && { status }),
      ...(category && { category }),
    };

    const [vendors, total] = await Promise.all([
      prisma.vendor.findMany({
        where,
        skip: (page - 1) * limit,
        take: limit,
        orderBy: { created_at: 'desc' },
      }),
      prisma.vendor.count({ where }),
    ]);

    return {
      vendors,
      meta: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  async createVendor(data: any) {
    return prisma.vendor.create({
      data: {
        ...data,
        status: 'PENDING_VERIFICATION',
      },
    });
  }

  // ... more methods
}

export const vendorsService = new VendorsService();
```

```typescript
// apps/server/src/modules/vendors/vendors.controller.ts
import { Request, Response } from 'express';
import { vendorsService } from './vendors.service';
import { ok, paginated, created } from '../../lib/response';

export class VendorsController {
  async getAll(req: Request, res: Response) {
    const result = await vendorsService.getAllVendors({
      status: req.query.status as any,
      category: req.query.category as string,
      page: parseInt(req.query.page as string) || 1,
      limit: parseInt(req.query.limit as string) || 20,
    });

    return paginated(res, result.vendors, result.meta);
  }

  async create(req: Request, res: Response) {
    const vendor = await vendorsService.createVendor(req.body);
    return created(res, vendor);
  }

  // ... more handlers
}

export const vendorsController = new VendorsController();
```

```typescript
// apps/server/src/modules/vendors/vendors.routes.ts
import { Router } from 'express';
import { vendorsController } from './vendors.controller';
import { authenticate, authorize } from '../../middleware/auth.middleware';
import { validate } from '../../middleware/validate.middleware';
import { CreateVendorSchema } from '@vendorbridge/shared';

const router = Router();

router.get(
  '/',
  authenticate,
  vendorsController.getAll.bind(vendorsController)
);

router.post(
  '/',
  authenticate,
  authorize('ADMIN', 'PROCUREMENT_OFFICER'),
  validate(CreateVendorSchema),
  vendorsController.create.bind(vendorsController)
);

export default router;
```

### Frontend Feature Example: Vendors

```typescript
// apps/client/src/features/vendors/api/useVendors.ts
import { useQuery } from '@tanstack/react-query';
import { apiClient } from '@/lib/api-client';

export function useVendors(filters?: any) {
  return useQuery({
    queryKey: ['vendors', filters],
    queryFn: () => apiClient.get('/vendors', { params: filters }),
  });
}

export function useCreateVendor() {
  return useMutation({
    mutationFn: (data: any) => apiClient.post('/vendors', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['vendors'] });
    },
  });
}
```

```typescript
// apps/client/src/features/vendors/components/VendorsList.tsx
import { useVendors } from '../api/useVendors';
import { DataTable } from '@/components/shared/DataTable';

export function VendorsList() {
  const { data, isLoading } = useVendors();

  if (isLoading) return <div>Loading...</div>;

  return (
    <DataTable
      data={data.vendors}
      columns={vendorColumns}
      meta={data.meta}
    />
  );
}
```

---

## 🔄 Real-Time Implementation

### Server Setup

```typescript
// apps/server/src/lib/socket.ts
import { Server } from 'socket.io';
import { Server as HttpServer } from 'http';

export function setupSocket(httpServer: HttpServer) {
  const io = new Server(httpServer, {
    cors: { origin: process.env.CLIENT_URL },
  });

  // Namespaces
  const procurementNs = io.of('/procurement');
  const vendorNs = io.of('/vendor');
  const adminNs = io.of('/admin');

  procurementNs.on('connection', (socket) => {
    const userId = socket.handshake.auth.userId;
    socket.join(`user:${userId}`);
    socket.join('org:procurement');
  });

  return { io, procurementNs, vendorNs, adminNs };
}
```

### Client Setup

```typescript
// apps/client/src/lib/socket-client.ts
import { io } from 'socket.io-client';

export const socket = io(`${API_URL}/procurement`, {
  auth: { token: getToken() },
});

// apps/client/src/hooks/useRealtime.ts
export function useRealtimeEvent<T>(event: string, handler: (data: T) => void) {
  useEffect(() => {
    socket.on(event, handler);
    return () => { socket.off(event, handler); };
  }, [event, handler]);
}
```

---

## 🤖 AI Assistant Implementation

```typescript
// apps/server/src/modules/ai-assistant/ai-assistant.service.ts
import Anthropic from '@anthropic-ai/sdk';

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

export async function chat(userId: string, messages: any[]) {
  // Get user context
  const context = await getProcurementContext(userId);
  
  const response = await anthropic.messages.create({
    model: 'claude-haiku-20240307',
    max_tokens: 1024,
    system: buildSystemPrompt(context),
    messages,
  });

  return response.content[0].text;
}
```

---

## ⛓️ Blockchain Implementation

```typescript
// apps/server/src/lib/blockchain.ts
import { ethers } from 'ethers';
import crypto from 'crypto';

const provider = new ethers.JsonRpcProvider(process.env.RPC_URL);
const wallet = new ethers.Wallet(process.env.BLOCKCHAIN_PRIVATE_KEY!, provider);
const contract = new ethers.Contract(
  process.env.CONTRACT_ADDRESS!,
  ABI,
  wallet
);

export async function anchorDocument(data: object) {
  const hash = '0x' + crypto
    .createHash('sha256')
    .update(JSON.stringify(data))
    .digest('hex');
    
  const tx = await contract.recordDocument(hash);
  await tx.wait();
  
  return { hash, tx: tx.hash };
}
```

---

## 📚 Complete File List

### Create These Files in Your Node.js Environment

**Shared Package:**
- `packages/shared/src/schemas/vendor.schema.ts`
- `packages/shared/src/schemas/rfq.schema.ts`
- `packages/shared/src/schemas/quotation.schema.ts`
- ... (all schemas)

**Server Modules:**
- `apps/server/src/modules/auth/*`
- `apps/server/src/modules/vendors/*`
- `apps/server/src/modules/rfq/*`
- ... (all modules)

**Server Infrastructure:**
- `apps/server/src/lib/prisma.ts`
- `apps/server/src/lib/redis.ts`
- `apps/server/src/lib/socket.ts`
- `apps/server/src/lib/queue.ts`
- `apps/server/src/lib/blockchain.ts`

**Client Features:**
- `apps/client/src/features/auth/*`
- `apps/client/src/features/vendors/*`
- ... (all features)

**Client Infrastructure:**
- `apps/client/src/lib/api-client.ts`
- `apps/client/src/lib/query-client.ts`
- `apps/client/src/lib/socket-client.ts`

---

## 🎯 Summary

**You Have:**
- ✅ Complete Prisma schema
- ✅ Docker Compose configuration
- ✅ Monorepo structure defined
- ✅ Complete architecture documentation
- ✅ Implementation patterns for all modules

**You Need:**
- ❌ Implement in separate Node.js environment (Figma Make blocks backend files)
- ❌ Follow the module patterns provided
- ❌ Set up Socket.IO, Bull, Redis integrations
- ❌ Implement AI assistant and blockchain features

**Estimated Time:** 2-3 weeks for full implementation

---

*See `PROJECT_RESTRUCTURE.md` for detailed architecture overview.*
*See Project Bible v2.0 for complete specifications.*
