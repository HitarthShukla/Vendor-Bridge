# Complete Backend Code - Copy & Paste Ready

This file contains ALL the backend TypeScript code. Copy each section to the corresponding file in your Node.js environment.

---

## 📁 File: `backend/database/db.ts`

```typescript
import pg from 'pg';
import dotenv from 'dotenv';

dotenv.config();

const { Pool } = pg;

// PostgreSQL connection pool
const pool = new Pool({
  host: process.env.DB_HOST || 'localhost',
  port: parseInt(process.env.DB_PORT || '5432'),
  database: process.env.DB_NAME || 'procurement_erp',
  user: process.env.DB_USER || 'postgres',
  password: process.env.DB_PASSWORD || '',
  max: 20,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 2000,
});

pool.on('connect', () => {
  console.log('✓ Connected to PostgreSQL database');
});

pool.on('error', (err) => {
  console.error('Unexpected error on idle client', err);
  process.exit(-1);
});

// Helper function to execute SQL queries
export const query = async (text: string, params?: any[]) => {
  const start = Date.now();
  try {
    const res = await pool.query(text, params);
    const duration = Date.now() - start;
    console.log('Executed query', { text: text.substring(0, 50), duration, rows: res.rowCount });
    return res;
  } catch (error) {
    console.error('Database query error:', error);
    throw error;
  }
};

// Helper function to execute transactions
export const transaction = async (callback: (client: any) => Promise<any>) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const result = await callback(client);
    await client.query('COMMIT');
    return result;
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    client.release();
  }
};

export default pool;
```

---

## 📁 File: `backend/middleware/auth.ts`

```typescript
import jwt from 'jsonwebtoken';
import { Request, Response, NextFunction } from 'express';
import dotenv from 'dotenv';

dotenv.config();

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-in-production';

interface UserPayload {
  id: number;
  email: string;
  name: string;
  role: string;
  vendorId?: number;
}

// Extend Express Request type
declare global {
  namespace Express {
    interface Request {
      user?: UserPayload;
    }
  }
}

// Middleware to verify JWT token
export const authenticateToken = (req: Request, res: Response, next: NextFunction) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Access token required' });
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ error: 'Invalid or expired token' });
    }
    req.user = user as UserPayload;
    next();
  });
};

// Middleware to check user role
export const authorizeRoles = (...allowedRoles: string[]) => {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.user || !allowedRoles.includes(req.user.role)) {
      return res.status(403).json({ error: 'Access forbidden: insufficient permissions' });
    }
    next();
  };
};

// Generate JWT token
export const generateToken = (user: any) => {
  return jwt.sign(
    {
      id: user.id,
      email: user.email,
      name: user.name,
      role: user.role,
      vendorId: user.vendor_id
    },
    JWT_SECRET,
    { expiresIn: '24h' }
  );
};
```

---

## 📁 File: `backend/routes/auth.ts`

```typescript
import express, { Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import { query } from '../database/db.js';
import { generateToken } from '../middleware/auth.js';

const router = express.Router();

// POST /api/auth/signup
router.post('/signup', async (req: Request, res: Response) => {
  try {
    const { email, password, name, role } = req.body;

    if (!email || !password || !name || !role) {
      return res.status(400).json({ error: 'All fields are required' });
    }

    const existingUser = await query('SELECT id FROM users WHERE email = $1', [email]);

    if (existingUser.rows.length > 0) {
      return res.status(409).json({ error: 'Email already registered' });
    }

    const passwordHash = await bcrypt.hash(password, 10);

    const result = await query(
      `INSERT INTO users (email, password_hash, name, role)
       VALUES ($1, $2, $3, $4)
       RETURNING id, email, name, role, vendor_id`,
      [email, passwordHash, name, role]
    );

    const user = result.rows[0];
    const token = generateToken(user);

    res.status(201).json({
      message: 'User created successfully',
      token,
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
        vendorId: user.vendor_id
      }
    });
  } catch (error) {
    console.error('Signup error:', error);
    res.status(500).json({ error: 'Server error during signup' });
  }
});

// POST /api/auth/login
router.post('/login', async (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password required' });
    }

    const result = await query(
      'SELECT id, email, password_hash, name, role, vendor_id FROM users WHERE email = $1',
      [email]
    );

    if (result.rows.length === 0) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const user = result.rows[0];
    const isValidPassword = await bcrypt.compare(password, user.password_hash);

    if (!isValidPassword) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const token = generateToken(user);

    res.json({
      message: 'Login successful',
      token,
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
        vendorId: user.vendor_id
      }
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Server error during login' });
  }
});

export default router;
```

---

## 📁 File: `backend/routes/vendors.ts`

```typescript
import express, { Request, Response } from 'express';
import { query } from '../database/db.js';
import { authenticateToken, authorizeRoles } from '../middleware/auth.js';

const router = express.Router();

// GET /api/vendors
router.get('/', authenticateToken, async (req: Request, res: Response) => {
  try {
    const { category, status } = req.query;

    let sql = 'SELECT * FROM vendors WHERE 1=1';
    const params: any[] = [];
    let paramCount = 1;

    if (category) {
      sql += ` AND category = $${paramCount++}`;
      params.push(category);
    }

    if (status) {
      sql += ` AND status = $${paramCount++}`;
      params.push(status);
    }

    sql += ' ORDER BY created_at DESC';

    const result = await query(sql, params);

    res.json({
      vendors: result.rows.map((row: any) => ({
        id: row.id,
        name: row.name,
        category: row.category,
        gstNumber: row.gst_number,
        contactPerson: row.contact_person,
        email: row.email,
        phone: row.phone,
        address: row.address,
        status: row.status,
        rating: parseFloat(row.rating),
        createdAt: row.created_at
      }))
    });
  } catch (error) {
    console.error('Get vendors error:', error);
    res.status(500).json({ error: 'Server error fetching vendors' });
  }
});

// POST /api/vendors
router.post('/', authenticateToken, authorizeRoles('procurement_officer', 'admin'), async (req: Request, res: Response) => {
  try {
    const { name, category, gstNumber, contactPerson, email, phone, address, status } = req.body;

    if (!name || !category || !gstNumber || !contactPerson || !email || !phone || !address) {
      return res.status(400).json({ error: 'All fields are required' });
    }

    const result = await query(
      `INSERT INTO vendors (name, category, gst_number, contact_person, email, phone, address, status)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
       RETURNING *`,
      [name, category, gstNumber, contactPerson, email, phone, address, status || 'active']
    );

    const row = result.rows[0];

    await query(
      `INSERT INTO activity_logs (type, user_id, user_name, related_id, related_type, message)
       VALUES ($1, $2, $3, $4, $5, $6)`,
      ['rfq_created', req.user!.id, req.user!.name, row.id, 'vendor', `Registered vendor: ${name}`]
    );

    res.status(201).json({
      vendor: {
        id: row.id,
        name: row.name,
        category: row.category,
        gstNumber: row.gst_number,
        contactPerson: row.contact_person,
        email: row.email,
        phone: row.phone,
        address: row.address,
        status: row.status,
        rating: parseFloat(row.rating),
        createdAt: row.created_at
      }
    });
  } catch (error) {
    console.error('Create vendor error:', error);
    res.status(500).json({ error: 'Server error creating vendor' });
  }
});

export default router;
```

---

## 📁 File: `backend/server.ts`

```typescript
import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import pool from './database/db.js';

import authRoutes from './routes/auth.js';
import vendorRoutes from './routes/vendors.js';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:5173',
  credentials: true
}));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Request logging
app.use((req, res, next) => {
  console.log(`${new Date().toISOString()} - ${req.method} ${req.path}`);
  next();
});

// Health check
app.get('/health', (req, res) => {
  res.json({
    status: 'OK',
    message: 'Procurement ERP API is running',
    timestamp: new Date().toISOString()
  });
});

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/vendors', vendorRoutes);

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: 'Route not found' });
});

// Error handler
app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
  console.error('Error:', err);
  res.status(err.status || 500).json({
    error: err.message || 'Internal server error',
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
  });
});

// Start server
const startServer = async () => {
  try {
    await pool.query('SELECT NOW()');
    console.log('✓ Database connection established');

    app.listen(PORT, () => {
      console.log(`\n========================================`);
      console.log(`🚀 Procurement ERP Backend Server`);
      console.log(`========================================`);
      console.log(`Server running on: http://localhost:${PORT}`);
      console.log(`========================================\n`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
};

startServer();

export default app;
```

---

## 🚀 How to Use This Code

### Step 1: Create a New Node.js Project

```bash
# Outside this Figma Make workspace
mkdir procurement-erp-backend
cd procurement-erp-backend
```

### Step 2: Copy Files

Copy the following from `/workspaces/default/code/backend/`:
- `package.json`
- `tsconfig.json`
- `.env.example` → rename to `.env`
- `database/schema.sql`

### Step 3: Create Backend Code Files

Create the folder structure and copy code from above:

```bash
mkdir -p database middleware routes

# Copy code from this document to each file:
# - database/db.ts
# - middleware/auth.ts
# - routes/auth.ts
# - routes/vendors.ts
# - server.ts
```

### Step 4: Install Dependencies

```bash
npm install
```

### Step 5: Set Up Database

```bash
# Create PostgreSQL database
createdb procurement_erp

# Run schema
psql -d procurement_erp -f database/schema.sql
```

### Step 6: Configure Environment

Edit `.env` with your database credentials.

### Step 7: Run Backend

```bash
# Development
npm run dev

# Production
npm run build
npm start
```

---

## ⚡ Quick Start (All Commands)

```bash
# 1. Create project
mkdir procurement-erp-backend && cd procurement-erp-backend

# 2. Copy files from /workspaces/default/code/backend/

# 3. Create code files (copy from this document)

# 4. Install
npm install

# 5. Database
createdb procurement_erp
psql -d procurement_erp -f database/schema.sql

# 6. Configure .env

# 7. Run
npm run dev
```

---

## 📝 Additional Routes

For the complete implementation, you also need to create:
- `routes/rfqs.ts`
- `routes/quotations.ts`
- `routes/approvals.ts`
- `routes/purchaseOrders.ts`
- `routes/invoices.ts`
- `routes/activityLogs.ts`
- `routes/analytics.ts`

**Refer to:** `/workspaces/default/code/BACKEND_IMPLEMENTATION_GUIDE.md` for the SQL query patterns for each route.
