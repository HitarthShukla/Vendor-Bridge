// Client entry point
// TODO: Migrate existing src/app/ code here
// See PROJECT_RESTRUCTURE.md for migration guide

import React from 'react';
import ReactDOM from 'react-dom/client';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <div style={{ padding: '2rem', fontFamily: 'system-ui' }}>
      <h1>VendorBridge Client</h1>
      <p>Frontend implementation pending</p>
      <p>See <code>PROJECT_RESTRUCTURE.md</code> for migration guide</p>
      <p>Existing code is in <code>/src/app/</code> directory</p>
    </div>
  </React.StrictMode>
);
