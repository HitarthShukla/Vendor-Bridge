# Procurement & Vendor Management ERP - Backend API

RESTful API server built with Node.js, Express, and PostgreSQL for the Procurement ERP system.

## Technology Stack

- **Runtime**: Node.js 18+
- **Framework**: Express.js
- **Database**: PostgreSQL 14+
- **Authentication**: JWT (JSON Web Tokens)
- **Password Hashing**: bcryptjs
- **Email**: Nodemailer (optional)

## Prerequisites

1. **Node.js** (v18 or higher)
2. **PostgreSQL** (v14 or higher)
3. **npm** or **pnpm**

## Setup Instructions

### 1. Install Dependencies

```bash
cd backend
npm install
```

### 2. Database Setup

#### Create PostgreSQL Database

```bash
# Connect to PostgreSQL
psql -U postgres

# Create database
CREATE DATABASE procurement_erp;

# Exit psql
\q
```

#### Run Database Schema

```bash
psql -U postgres -d procurement_erp -f database/schema.sql
```

### 3. Environment Configuration

Create a `.env` file in the backend directory:

```bash
cp .env.example .env
```

Edit `.env` with your configuration:

```env
PORT=5000
NODE_ENV=development

# PostgreSQL Configuration
DB_HOST=localhost
DB_PORT=5432
DB_NAME=procurement_erp
DB_USER=postgres
DB_PASSWORD=your_password

# JWT Secret (generate a random string)
JWT_SECRET=your_secret_key_here

# Email Configuration (Optional)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your_email@gmail.com
SMTP_PASSWORD=your_app_password
SMTP_FROM=noreply@procurement-erp.com
```

### 4. Start the Server

#### Development Mode

```bash
npm run dev
```

#### Production Mode

```bash
npm start
```

The server will start on `http://localhost:5000`

## API Documentation

### Authentication Endpoints

#### POST /api/auth/signup
Register a new user account

**Request Body:**
```json
{
  "email": "user@example.com",
  "password": "password123",
  "name": "John Doe",
  "role": "procurement_officer"
}
```

**Response:**
```json
{
  "message": "User created successfully",
  "token": "jwt_token_here",
  "user": {
    "id": 1,
    "email": "user@example.com",
    "name": "John Doe",
    "role": "procurement_officer",
    "vendorId": null
  }
}
```

#### POST /api/auth/login
Login to existing account

**Request Body:**
```json
{
  "email": "user@example.com",
  "password": "password123"
}
```

### Vendor Endpoints

- `GET /api/vendors` - Get all vendors (with optional filters)
- `GET /api/vendors/:id` - Get vendor by ID
- `POST /api/vendors` - Create new vendor (Procurement Officer/Admin only)
- `PUT /api/vendors/:id` - Update vendor (Procurement Officer/Admin only)

### RFQ Endpoints

- `GET /api/rfqs` - Get all RFQs
- `POST /api/rfqs` - Create new RFQ
- `PUT /api/rfqs/:id/send` - Send RFQ to vendors

### Quotation Endpoints

- `GET /api/quotations` - Get all quotations
- `POST /api/quotations` - Submit quotation (Vendor only)
- `PUT /api/quotations/:id/accept` - Accept quotation
- `PUT /api/quotations/:id/reject` - Reject quotation

### Approval Endpoints

- `GET /api/approvals` - Get approval workflows (Manager/Admin only)
- `PUT /api/approvals/:id/approve` - Approve request (Manager/Admin only)
- `PUT /api/approvals/:id/reject` - Reject request (Manager/Admin only)

### Purchase Order Endpoints

- `GET /api/purchase-orders` - Get all purchase orders
- `GET /api/purchase-orders/:id` - Get purchase order by ID
- `PUT /api/purchase-orders/:id/status` - Update PO status

### Invoice Endpoints

- `GET /api/invoices` - Get all invoices
- `POST /api/invoices` - Generate invoice from PO
- `POST /api/invoices/:id/send` - Send invoice via email

### Activity Log Endpoints

- `GET /api/activity-logs` - Get activity logs
- `GET /api/activity-logs/stats` - Get activity statistics

### Analytics Endpoints

- `GET /api/analytics/dashboard` - Get dashboard analytics
- `GET /api/analytics/vendor-performance` - Get vendor performance metrics
- `GET /api/analytics/category-spending` - Get spending by category

## Database Schema

The database includes the following main tables:

- **users** - User accounts with roles
- **vendors** - Vendor/supplier information
- **rfqs** - Request for Quotations
- **rfq_items** - Items in each RFQ
- **rfq_vendors** - Many-to-many relationship between RFQs and vendors
- **quotations** - Vendor quotations
- **quotation_items** - Items in each quotation
- **approval_workflows** - Approval process tracking
- **purchase_orders** - Purchase orders
- **purchase_order_items** - Items in each PO
- **invoices** - Invoices
- **invoice_items** - Items in each invoice
- **activity_logs** - Audit trail

## Authentication & Authorization

All API endpoints (except auth endpoints) require JWT authentication via Bearer token:

```
Authorization: Bearer <token>
```

Role-based access control:
- **Procurement Officer**: Create RFQs, manage vendors, accept quotations
- **Vendor**: View assigned RFQs, submit quotations
- **Manager/Approver**: Approve/reject procurement requests
- **Admin**: Full access to all features

## SQL Query Examples

The backend uses structured SQL queries for all database operations:

```sql
-- Get vendors with filters
SELECT * FROM vendors WHERE category = $1 AND status = $2 ORDER BY created_at DESC;

-- Create RFQ with transaction
BEGIN;
INSERT INTO rfqs (rfq_number, title, deadline, created_by) VALUES ($1, $2, $3, $4) RETURNING *;
INSERT INTO rfq_items (rfq_id, product_service, quantity, unit) VALUES ($1, $2, $3, $4);
COMMIT;

-- Get quotations with items (JOIN)
SELECT q.*, qi.unit_price, qi.total_price 
FROM quotations q
JOIN quotation_items qi ON q.id = qi.quotation_id
WHERE q.rfq_id = $1;
```

## Error Handling

The API returns consistent error responses:

```json
{
  "error": "Error message description"
}
```

HTTP Status Codes:
- `200` - Success
- `201` - Created
- `400` - Bad Request
- `401` - Unauthorized
- `403` - Forbidden
- `404` - Not Found
- `409` - Conflict
- `500` - Internal Server Error

## Demo Data

The database schema includes demo data:
- 4 demo users (one for each role)
- 4 demo vendors

**Demo Accounts:**
- Procurement Officer: `officer@demo.com` / `demo123`
- Vendor: `vendor@demo.com` / `demo123`
- Manager: `manager@demo.com` / `demo123`
- Admin: `admin@demo.com` / `demo123`

## Production Deployment

1. Set `NODE_ENV=production` in `.env`
2. Use a strong JWT_SECRET
3. Configure proper database credentials
4. Set up SMTP for email functionality
5. Use a reverse proxy (nginx) for SSL/TLS
6. Implement rate limiting and request validation
7. Set up database backups
8. Monitor logs and performance

## License

MIT
