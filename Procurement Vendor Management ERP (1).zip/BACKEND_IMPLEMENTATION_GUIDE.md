# Backend Implementation Guide

## Important Note

This Figma Make environment is designed for **frontend TypeScript/React applications** and blocks creating `.js` files. The backend must be set up in a **separate Node.js environment** outside of this Figma Make workspace.

## Complete Backend Implementation

I've created comprehensive backend specifications in the `/backend` folder including:

✅ **Database Schema** (`backend/database/schema.sql`)
   - Complete PostgreSQL schema with all tables
   - Foreign keys, indexes, and constraints
   - Demo data for all 4 user roles
   - SQL commands for all operations

✅ **API Documentation** (`backend/README.md`)
   - All API endpoints documented
   - Request/response examples
   - Authentication & authorization details
   - SQL query patterns

✅ **Setup Guide** (`SETUP_INSTRUCTIONS.md`)
   - Step-by-step PostgreSQL setup
   - Environment configuration
   - Testing procedures
   - Troubleshooting guide

## How to Implement the Backend

### Option 1: Implement Locally (Recommended)

1. **Create a separate directory** outside this Figma Make workspace:
```bash
cd ~
mkdir procurement-erp-backend
cd procurement-erp-backend
```

2. **Copy the specification files** from this project:
   - `/backend/package.json`
   - `/backend/.env.example`
   - `/backend/database/schema.sql`
   - `/backend/README.md`

3. **Implement the backend** following the API specifications in `backend/README.md`. Each route file should implement the SQL queries as documented.

### Option 2: Use the Provided Code (Copy-Paste)

I've written complete backend code that you can copy from the following files. Since this environment blocks `.js` files, you'll need to copy them manually to your local environment:

**Core Files to Create:**

1. **database/db.ts** - PostgreSQL connection pool
2. **middleware/auth.ts** - JWT authentication
3. **routes/auth.ts** - Authentication endpoints
4. **routes/vendors.ts** - Vendor CRUD operations
5. **routes/rfqs.ts** - RFQ management
6. **routes/quotations.ts** - Quotation handling
7. **routes/approvals.ts** - Approval workflows
8. **routes/purchaseOrders.ts** - PO management
9. **routes/invoices.ts** - Invoice generation
10. **routes/activityLogs.ts** - Activity tracking
11. **routes/analytics.ts** - Analytics & reports
12. **server.ts** - Express server entry point

## Key SQL Queries by Feature

### 1. Vendor Management

**Get All Vendors (with filters):**
```sql
SELECT * FROM vendors 
WHERE category = $1 AND status = $2 
ORDER BY created_at DESC;
```

**Create Vendor:**
```sql
INSERT INTO vendors (
  name, category, gst_number, contact_person, 
  email, phone, address, status
) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
RETURNING *;
```

### 2. RFQ Management

**Create RFQ (Transaction):**
```sql
BEGIN;

INSERT INTO rfqs (rfq_number, title, deadline, created_by, status)
VALUES ($1, $2, $3, $4, 'draft')
RETURNING *;

INSERT INTO rfq_items (rfq_id, product_service, description, quantity, unit)
VALUES ($1, $2, $3, $4, $5);

INSERT INTO rfq_vendors (rfq_id, vendor_id)
VALUES ($1, $2);

COMMIT;
```

**Get RFQs with Items (JOIN):**
```sql
SELECT 
  r.*,
  u.name as creator_name,
  ri.id as item_id,
  ri.product_service,
  ri.quantity,
  ri.unit
FROM rfqs r
LEFT JOIN users u ON r.created_by = u.id
LEFT JOIN rfq_items ri ON r.id = ri.rfq_id
ORDER BY r.created_at DESC;
```

### 3. Quotation Management

**Submit Quotation (Transaction):**
```sql
BEGIN;

INSERT INTO quotations (
  quotation_number, rfq_id, vendor_id, 
  delivery_timeline, notes, status, submitted_at
) VALUES ($1, $2, $3, $4, $5, 'submitted', CURRENT_TIMESTAMP)
RETURNING *;

INSERT INTO quotation_items (quotation_id, rfq_item_id, unit_price, total_price)
VALUES ($1, $2, $3, $4);

COMMIT;
```

**Compare Quotations:**
```sql
SELECT 
  q.*,
  v.name as vendor_name,
  v.rating,
  qi.rfq_item_id,
  qi.unit_price,
  qi.total_price,
  SUM(qi.total_price) OVER (PARTITION BY q.id) as total_amount
FROM quotations q
JOIN vendors v ON q.vendor_id = v.id
JOIN quotation_items qi ON q.id = qi.quotation_id
WHERE q.rfq_id = $1 AND q.status = 'submitted'
ORDER BY total_amount ASC;
```

### 4. Approval Workflow

**Approve and Create PO (Transaction):**
```sql
BEGIN;

-- Update approval
UPDATE approval_workflows
SET status = 'approved', approver = $1, remarks = $2, decided_at = CURRENT_TIMESTAMP
WHERE id = $3
RETURNING *;

-- Create Purchase Order
INSERT INTO purchase_orders (
  po_number, quotation_id, rfq_id, vendor_id,
  subtotal, tax, total, status
) VALUES ($1, $2, $3, $4, $5, $6, $7, 'draft')
RETURNING *;

-- Insert PO items
INSERT INTO purchase_order_items (po_id, product_service, quantity, unit_price, total_price)
SELECT $1, ri.product_service, ri.quantity, qi.unit_price, qi.total_price
FROM quotation_items qi
JOIN rfq_items ri ON qi.rfq_item_id = ri.id
WHERE qi.quotation_id = $2;

COMMIT;
```

### 5. Analytics

**Dashboard Metrics:**
```sql
-- Total spending
SELECT COALESCE(SUM(total), 0) as total_spending 
FROM purchase_orders;

-- Vendor performance
SELECT 
  v.id,
  v.name,
  v.rating,
  COUNT(DISTINCT q.id) as total_quotations,
  COUNT(DISTINCT CASE WHEN q.status = 'accepted' THEN q.id END) as accepted,
  COALESCE(SUM(po.total), 0) as total_spending
FROM vendors v
LEFT JOIN quotations q ON v.id = q.vendor_id
LEFT JOIN purchase_orders po ON v.id = po.vendor_id
WHERE v.status = 'active'
GROUP BY v.id, v.name, v.rating
HAVING COUNT(DISTINCT q.id) > 0
ORDER BY total_spending DESC;

-- Category spending
SELECT 
  v.category,
  COALESCE(SUM(po.total), 0) as total_spending
FROM vendors v
LEFT JOIN purchase_orders po ON v.id = po.vendor_id
GROUP BY v.category
HAVING SUM(po.total) > 0
ORDER BY total_spending DESC;
```

## Frontend Integration

To connect the frontend to the backend, you need to replace all `localStorage` calls with API calls.

### Create API Client (`src/app/utils/api.ts`):

```typescript
const API_BASE_URL = 'http://localhost:5000/api';

class APIClient {
  private getToken(): string | null {
    return localStorage.getItem('token');
  }

  private async request<T>(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<T> {
    const token = this.getToken();

    const headers: HeadersInit = {
      'Content-Type': 'application/json',
      ...(token && { Authorization: `Bearer ${token}` }),
      ...options.headers,
    };

    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      ...options,
      headers,
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'API request failed');
    }

    return response.json();
  }

  // Authentication
  async login(email: string, password: string) {
    const data = await this.request<{ token: string; user: any }>('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
    
    localStorage.setItem('token', data.token);
    return data;
  }

  async signup(email: string, password: string, name: string, role: string) {
    const data = await this.request<{ token: string; user: any }>('/auth/signup', {
      method: 'POST',
      body: JSON.stringify({ email, password, name, role }),
    });
    
    localStorage.setItem('token', data.token);
    return data;
  }

  // Vendors
  async getVendors(filters?: { category?: string; status?: string }) {
    const params = new URLSearchParams(filters as any);
    return this.request<{ vendors: any[] }>(`/vendors?${params}`);
  }

  async createVendor(vendor: any) {
    return this.request<{ vendor: any }>('/vendors', {
      method: 'POST',
      body: JSON.stringify(vendor),
    });
  }

  // RFQs
  async getRFQs() {
    return this.request<{ rfqs: any[] }>('/rfqs');
  }

  async createRFQ(rfq: any) {
    return this.request<{ rfq: any }>('/rfqs', {
      method: 'POST',
      body: JSON.stringify(rfq),
    });
  }

  async sendRFQ(id: number) {
    return this.request(`/rfqs/${id}/send`, {
      method: 'PUT',
    });
  }

  // Quotations
  async getQuotations(rfqId?: number) {
    const params = rfqId ? `?rfqId=${rfqId}` : '';
    return this.request<{ quotations: any[] }>(`/quotations${params}`);
  }

  async submitQuotation(quotation: any) {
    return this.request<{ quotation: any }>('/quotations', {
      method: 'POST',
      body: JSON.stringify(quotation),
    });
  }

  async acceptQuotation(id: number) {
    return this.request(`/quotations/${id}/accept`, {
      method: 'PUT',
    });
  }

  // ... add other methods
}

export const api = new APIClient();
```

### Update AuthContext to use API:

```typescript
const login = async (email: string, password: string): Promise<boolean> => {
  try {
    const { user } = await api.login(email, password);
    setUser(user);
    return true;
  } catch (error) {
    console.error('Login error:', error);
    return false;
  }
};
```

## Deployment Steps

### 1. Set up PostgreSQL Database

```bash
# Install PostgreSQL
sudo apt install postgresql

# Create database
sudo -u postgres createdb procurement_erp

# Run schema
sudo -u postgres psql -d procurement_erp -f backend/database/schema.sql
```

### 2. Configure Backend

```bash
# Install dependencies
cd backend
npm install

# Set up environment
cp .env.example .env
# Edit .env with your database credentials

# Build TypeScript
npm run build

# Start server
npm start
```

### 3. Build and Deploy Frontend

```bash
# Build frontend
pnpm build

# Deploy to hosting (Netlify, Vercel, etc.)
```

## Production Checklist

- [ ] Set strong JWT_SECRET
- [ ] Enable SSL/TLS (HTTPS)
- [ ] Configure CORS for production domain
- [ ] Set up database backups
- [ ] Enable database connection pooling
- [ ] Add rate limiting
- [ ] Implement request logging
- [ ] Set up error monitoring (Sentry, etc.)
- [ ] Configure email SMTP for production
- [ ] Set up CI/CD pipeline
- [ ] Add automated tests

## Demo Data

After running the schema, these accounts are available:

| Role | Email | Password |
|------|-------|----------|
| Procurement Officer | officer@demo.com | demo123 |
| Vendor | vendor@demo.com | demo123 |
| Manager | manager@demo.com | demo123 |
| Admin | admin@demo.com | demo123 |

## Support

The complete backend specifications are provided in:
- `/backend/database/schema.sql` - Database schema with all SQL
- `/backend/README.md` - API documentation
- `/SETUP_INSTRUCTIONS.md` - Detailed setup guide
- This file - Implementation patterns and examples

Implement the backend in a separate Node.js environment following these specifications and the SQL patterns provided.
