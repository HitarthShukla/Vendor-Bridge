# VendorBridge Project Restructure

This document outlines the complete restructuring of the Procurement ERP system according to the VendorBridge Project Bible v2.0.

---

## 🎯 New Architecture Overview

### Current Structure (Simple)
```
/workspaces/default/code/
├── src/app/              # React frontend
├── backend/              # Specifications only
└── docs/
```

### New Structure (Monorepo)
```
vendorbridge/
├── packages/
│   └── shared/           # Shared Zod schemas + types
├── apps/
│   ├── server/           # Express + Prisma backend
│   └── client/           # React + Vite frontend
├── docker-compose.yml
└── README.md
```

---

## 📦 Technology Changes

| Component | Old | New |
|-----------|-----|-----|
| **Database ORM** | Raw SQL queries | **Prisma ORM** |
| **ID Type** | SERIAL/INTEGER | **UUID** (gen_random_uuid()) |
| **State Management** | Context API | **TanStack Query + Zustand** |
| **UI Components** | Material-UI + Radix | **shadcn/ui** (Radix primitives) |
| **Validation** | Basic checks | **Zod schemas** (shared package) |
| **Real-time** | Not implemented | **Socket.IO** |
| **Background Jobs** | Not implemented | **Bull + Redis** |
| **Caching** | localStorage only | **Redis + TanStack Query** |
| **File Storage** | Not implemented | **Local uploads/ folder** |
| **PDF Generation** | jsPDF (client) | **Puppeteer** (server) |
| **AI Assistant** | Not implemented | **Claude API** (Anthropic) |
| **Blockchain** | Not implemented | **Ethereum** (Hardhat + Polygon) |

---

## 🗂️ Detailed Folder Structure

### Monorepo Root

```
vendorbridge/
├── .github/
│   └── workflows/
│       └── ci.yml                    # GitHub Actions CI
│
├── packages/
│   └── shared/                       # Shared package
│       ├── src/
│       │   ├── schemas/              # Zod schemas
│       │   │   ├── auth.schema.ts
│       │   │   ├── vendor.schema.ts
│       │   │   ├── rfq.schema.ts
│       │   │   ├── quotation.schema.ts
│       │   │   ├── approval.schema.ts
│       │   │   ├── purchase-order.schema.ts
│       │   │   └── invoice.schema.ts
│       │   ├── types/                # TypeScript types
│       │   │   └── index.ts
│       │   └── index.ts
│       ├── package.json
│       └── tsconfig.json
│
├── apps/
│   ├── server/                       # Backend application
│   │   ├── src/
│   │   │   ├── modules/              # Feature modules
│   │   │   │   ├── auth/
│   │   │   │   │   ├── auth.controller.ts
│   │   │   │   │   ├── auth.service.ts
│   │   │   │   │   ├── auth.routes.ts
│   │   │   │   │   └── auth.types.ts
│   │   │   │   ├── vendors/
│   │   │   │   │   ├── vendors.controller.ts
│   │   │   │   │   ├── vendors.service.ts
│   │   │   │   │   ├── vendors.routes.ts
│   │   │   │   │   └── vendors.types.ts
│   │   │   │   ├── rfq/
│   │   │   │   ├── quotations/
│   │   │   │   ├── approvals/
│   │   │   │   ├── purchase-orders/
│   │   │   │   ├── invoices/
│   │   │   │   ├── activity-logs/
│   │   │   │   ├── reports/
│   │   │   │   ├── ai-assistant/
│   │   │   │   └── blockchain/
│   │   │   │
│   │   │   ├── middleware/
│   │   │   │   ├── auth.middleware.ts
│   │   │   │   ├── rbac.middleware.ts
│   │   │   │   ├── validate.middleware.ts
│   │   │   │   ├── error.middleware.ts
│   │   │   │   └── rate-limit.middleware.ts
│   │   │   │
│   │   │   ├── lib/
│   │   │   │   ├── prisma.ts         # Prisma client
│   │   │   │   ├── redis.ts          # Redis client
│   │   │   │   ├── socket.ts         # Socket.IO setup
│   │   │   │   ├── mailer.ts         # Nodemailer config
│   │   │   │   ├── queue.ts          # Bull queue
│   │   │   │   ├── blockchain.ts     # Ethers.js
│   │   │   │   ├── response.ts       # Response helpers
│   │   │   │   └── document-id.ts    # ID generator
│   │   │   │
│   │   │   ├── jobs/                 # Background job processors
│   │   │   │   ├── pdf.job.ts
│   │   │   │   ├── email.job.ts
│   │   │   │   └── blockchain.job.ts
│   │   │   │
│   │   │   ├── app.ts                # Express app factory
│   │   │   └── server.ts             # Server entry point
│   │   │
│   │   ├── prisma/
│   │   │   ├── schema.prisma         # Prisma schema
│   │   │   ├── migrations/           # Migration files
│   │   │   └── seed.ts               # Database seeder
│   │   │
│   │   ├── uploads/                  # File uploads
│   │   ├── .env.example
│   │   ├── package.json
│   │   └── tsconfig.json
│   │
│   └── client/                       # Frontend application
│       ├── src/
│       │   ├── components/
│       │   │   ├── ui/               # shadcn/ui components
│       │   │   │   ├── button.tsx
│       │   │   │   ├── card.tsx
│       │   │   │   ├── dialog.tsx
│       │   │   │   ├── input.tsx
│       │   │   │   ├── table.tsx
│       │   │   │   └── ...
│       │   │   └── shared/           # Shared components
│       │   │       ├── StatusBadge.tsx
│       │   │       ├── DataTable.tsx
│       │   │       ├── PageHeader.tsx
│       │   │       └── ...
│       │   │
│       │   ├── features/             # Feature modules
│       │   │   ├── auth/
│       │   │   │   ├── api/
│       │   │   │   │   ├── useLogin.ts
│       │   │   │   │   └── useRegister.ts
│       │   │   │   ├── components/
│       │   │   │   │   ├── LoginForm.tsx
│       │   │   │   │   └── RegisterForm.tsx
│       │   │   │   ├── hooks/
│       │   │   │   │   └── useAuth.ts
│       │   │   │   ├── types.ts
│       │   │   │   └── index.ts
│       │   │   ├── vendors/
│       │   │   ├── rfq/
│       │   │   ├── quotations/
│       │   │   ├── approvals/
│       │   │   ├── purchase-orders/
│       │   │   ├── invoices/
│       │   │   ├── activity-logs/
│       │   │   ├── reports/
│       │   │   ├── ai-assistant/
│       │   │   └── blockchain/
│       │   │
│       │   ├── hooks/                # Global hooks
│       │   │   ├── useAuth.ts
│       │   │   ├── useSocket.ts
│       │   │   └── useRealtime.ts
│       │   │
│       │   ├── layouts/
│       │   │   ├── AppLayout.tsx
│       │   │   ├── AuthLayout.tsx
│       │   │   └── VendorLayout.tsx
│       │   │
│       │   ├── lib/
│       │   │   ├── api-client.ts     # Axios instance
│       │   │   ├── query-client.ts   # TanStack Query
│       │   │   ├── socket-client.ts  # Socket.IO client
│       │   │   └── utils.ts
│       │   │
│       │   ├── routes/               # Route definitions
│       │   │   ├── index.tsx
│       │   │   └── guards.tsx
│       │   │
│       │   ├── store/                # Zustand stores
│       │   │   ├── auth.store.ts
│       │   │   ├── ui.store.ts
│       │   │   └── socket.store.ts
│       │   │
│       │   ├── types/                # Client types
│       │   │   └── index.ts
│       │   │
│       │   ├── App.tsx
│       │   └── main.tsx
│       │
│       ├── public/
│       ├── .env.example
│       ├── package.json
│       ├── tailwind.config.js
│       ├── vite.config.ts
│       └── tsconfig.json
│
├── contracts/                        # Smart contracts
│   ├── AuditTrail.sol
│   └── hardhat.config.ts
│
├── docker-compose.yml                # PostgreSQL + Redis
├── package.json                      # Root package.json
├── pnpm-workspace.yaml               # pnpm workspace config
├── turbo.json                        # Optional: Turborepo
└── README.md
```

---

## 🗄️ Database Changes

### Old Schema (Raw SQL)
- Used SERIAL IDs
- Basic structure
- No soft deletes
- Simple enums

### New Schema (Prisma)
- **UUID** primary keys
- **Soft deletes** (deleted_at)
- **Timestamps** with triggers
- **JSONB** columns for flexible data
- **Enums** for all status fields
- **Comprehensive relationships**
- **Proper indexes**

---

## 🔄 Migration Path

Since this is a complete restructure, here's the recommended approach:

### Option 1: Fresh Start (Recommended)
1. Create new monorepo structure
2. Implement with Prisma from scratch
3. Keep old code as reference
4. Test thoroughly before deployment

### Option 2: Gradual Migration
1. Set up monorepo structure
2. Create Prisma schema matching existing DB
3. Migrate module by module
4. Dual deployment during transition

---

## 📋 Implementation Checklist

### Phase 1: Infrastructure Setup
- [ ] Create monorepo structure
- [ ] Set up pnpm workspace
- [ ] Configure Docker Compose (PostgreSQL + Redis)
- [ ] Set up Prisma
- [ ] Create shared package with Zod schemas

### Phase 2: Backend Setup
- [ ] Create module structure
- [ ] Implement auth module (JWT + refresh tokens)
- [ ] Implement vendors module
- [ ] Implement RFQ module
- [ ] Implement quotations module
- [ ] Implement approvals module
- [ ] Implement purchase orders module
- [ ] Implement invoices module
- [ ] Set up Socket.IO
- [ ] Set up Bull queues
- [ ] Implement blockchain integration

### Phase 3: Frontend Setup
- [ ] Set up Vite + React
- [ ] Install shadcn/ui components
- [ ] Set up TanStack Query
- [ ] Set up Zustand stores
- [ ] Create feature modules
- [ ] Implement Socket.IO client
- [ ] Create layouts
- [ ] Implement routing with guards

### Phase 4: Advanced Features
- [ ] AI Assistant with Claude API
- [ ] Blockchain audit trail
- [ ] Real-time notifications
- [ ] Background PDF generation
- [ ] Email delivery
- [ ] File uploads

### Phase 5: Testing & Deployment
- [ ] Write unit tests (Vitest)
- [ ] Write integration tests
- [ ] Set up GitHub Actions CI
- [ ] Configure production deployment

---

## 🚀 Quick Start Commands

### Development Setup
```bash
# Install dependencies
pnpm install

# Start Docker containers
docker-compose up -d

# Generate Prisma client
cd apps/server
pnpm prisma generate

# Run migrations
pnpm prisma migrate dev

# Seed database
pnpm prisma db seed

# Start development servers
cd ../..
pnpm dev  # Starts both client and server
```

### Individual Services
```bash
# Backend only
cd apps/server
pnpm dev

# Frontend only
cd apps/client
pnpm dev

# Database GUI
cd apps/server
pnpm prisma studio
```

---

## 📚 Key Differences Summary

| Aspect | Old | New |
|--------|-----|-----|
| **Structure** | Flat | Monorepo |
| **Database** | Raw SQL | Prisma ORM |
| **IDs** | Integer | UUID |
| **Validation** | Manual | Zod schemas |
| **State** | Context | TanStack Query + Zustand |
| **UI** | MUI/Radix | shadcn/ui |
| **Real-time** | None | Socket.IO |
| **Jobs** | None | Bull + Redis |
| **AI** | None | Claude API |
| **Blockchain** | None | Ethereum |
| **Modules** | Loose | Strict feature modules |

---

## 📖 Next Steps

See individual implementation guides:
- `PRISMA_SETUP.md` - Database schema and migrations
- `BACKEND_MODULES.md` - Module implementation patterns
- `FRONTEND_FEATURES.md` - Feature module structure
- `REALTIME_GUIDE.md` - Socket.IO implementation
- `BLOCKCHAIN_GUIDE.md` - Smart contract integration
- `AI_ASSISTANT.md` - Claude API integration

---

*Note: This restructure transforms the project into a production-grade, scalable enterprise application following modern best practices.*
