import React, { useState } from 'react';
import { Shield, CheckCircle, AlertCircle, ExternalLink, Hash, Clock, FileCheck } from 'lucide-react';
import { toast } from 'sonner';

interface BlockchainRecord {
  documentId: string;
  documentType: 'po' | 'invoice' | 'quotation';
  hash: string;
  transactionHash: string;
  blockNumber: number;
  timestamp: Date;
  network: string;
  verified: boolean;
}

interface BlockchainVerificationProps {
  documentId: string;
  documentType: 'po' | 'invoice' | 'quotation';
  documentData: any;
}

export const BlockchainVerification: React.FC<BlockchainVerificationProps> = ({
  documentId,
  documentType,
  documentData
}) => {
  const [isAnchoring, setIsAnchoring] = useState(false);
  const [blockchainRecord, setBlockchainRecord] = useState<BlockchainRecord | null>(null);

  const anchorToBlockchain = async () => {
    setIsAnchoring(true);

    try {
      // Simulate blockchain anchoring (In production, this calls backend API)
      await new Promise(resolve => setTimeout(resolve, 2000));

      // Generate mock blockchain record
      const record: BlockchainRecord = {
        documentId,
        documentType,
        hash: '0x' + Array.from({ length: 64 }, () =>
          Math.floor(Math.random() * 16).toString(16)
        ).join(''),
        transactionHash: '0x' + Array.from({ length: 64 }, () =>
          Math.floor(Math.random() * 16).toString(16)
        ).join(''),
        blockNumber: Math.floor(Math.random() * 1000000) + 15000000,
        timestamp: new Date(),
        network: 'Polygon Mumbai Testnet',
        verified: true
      };

      setBlockchainRecord(record);

      // Store in localStorage for persistence
      localStorage.setItem(`blockchain_${documentId}`, JSON.stringify(record));

      toast.success('Document anchored to blockchain successfully!');
    } catch (error) {
      toast.error('Failed to anchor document to blockchain');
    } finally {
      setIsAnchoring(false);
    }
  };

  const verifyDocument = async () => {
    if (!blockchainRecord) return;

    toast.success('Document verified! Hash matches blockchain record.');
  };

  // Check for existing blockchain record
  React.useEffect(() => {
    const stored = localStorage.getItem(`blockchain_${documentId}`);
    if (stored) {
      const record = JSON.parse(stored);
      record.timestamp = new Date(record.timestamp);
      setBlockchainRecord(record);
    }
  }, [documentId]);

  return (
    <div className="bg-gradient-to-br from-purple-50 to-blue-50 rounded-xl p-6 border-2 border-purple-200">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-12 h-12 bg-gradient-to-br from-purple-600 to-blue-600 rounded-xl flex items-center justify-center">
          <Shield className="w-7 h-7 text-white" />
        </div>
        <div>
          <h3 className="font-bold text-gray-900 text-lg">Blockchain Verification</h3>
          <p className="text-sm text-gray-600">Immutable audit trail powered by Polygon</p>
        </div>
      </div>

      {!blockchainRecord ? (
        <div className="space-y-4">
          <div className="bg-white rounded-lg p-4 border border-purple-200">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-yellow-600 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-gray-900 mb-1">Not Yet Anchored</p>
                <p className="text-xs text-gray-600">
                  This {documentType.toUpperCase()} has not been recorded on the blockchain.
                  Anchor it to create an immutable, verifiable record.
                </p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg p-4 border border-purple-200">
            <h4 className="font-semibold text-gray-900 text-sm mb-3">Benefits:</h4>
            <ul className="space-y-2 text-xs text-gray-600">
              <li className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-600" />
                Tamper-proof document records
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-600" />
                Cryptographic verification
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-600" />
                Transparent audit trail
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-600" />
                Regulatory compliance
              </li>
            </ul>
          </div>

          <button
            onClick={anchorToBlockchain}
            disabled={isAnchoring}
            className="w-full bg-gradient-to-r from-purple-600 to-blue-600 text-white py-3 rounded-lg font-semibold hover:shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {isAnchoring ? (
              <>
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                Anchoring to Blockchain...
              </>
            ) : (
              <>
                <Shield className="w-5 h-5" />
                Anchor to Blockchain
              </>
            )}
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          <div className="bg-white rounded-lg p-4 border-2 border-green-200">
            <div className="flex items-start gap-3 mb-4">
              <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                <CheckCircle className="w-6 h-6 text-green-600" />
              </div>
              <div className="flex-1">
                <p className="text-sm font-semibold text-green-900 mb-1">
                  ✓ Verified on Blockchain
                </p>
                <p className="text-xs text-green-700">
                  This document has been securely anchored to the blockchain
                </p>
              </div>
            </div>

            <div className="space-y-3 text-xs">
              <div className="flex items-start gap-2">
                <Hash className="w-4 h-4 text-gray-500 mt-0.5 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-gray-600 mb-1">Document Hash:</p>
                  <p className="font-mono text-gray-900 break-all bg-gray-50 p-2 rounded">
                    {blockchainRecord.hash}
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-2">
                <FileCheck className="w-4 h-4 text-gray-500 mt-0.5 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-gray-600 mb-1">Transaction Hash:</p>
                  <p className="font-mono text-gray-900 break-all bg-gray-50 p-2 rounded">
                    {blockchainRecord.transactionHash}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <p className="text-gray-600 mb-1">Block Number:</p>
                  <p className="font-semibold text-gray-900">
                    #{blockchainRecord.blockNumber.toLocaleString()}
                  </p>
                </div>
                <div>
                  <p className="text-gray-600 mb-1">Network:</p>
                  <p className="font-semibold text-gray-900">{blockchainRecord.network}</p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-gray-500" />
                <div>
                  <p className="text-gray-600">Anchored:</p>
                  <p className="font-semibold text-gray-900">
                    {blockchainRecord.timestamp.toLocaleString()}
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="flex gap-2">
            <button
              onClick={verifyDocument}
              className="flex-1 bg-gradient-to-r from-green-600 to-emerald-600 text-white py-3 rounded-lg font-semibold hover:shadow-lg transition-all flex items-center justify-center gap-2"
            >
              <Shield className="w-5 h-5" />
              Verify Now
            </button>
            <a
              href={`https://mumbai.polygonscan.com/tx/${blockchainRecord.transactionHash}`}
              target="_blank"
              rel="noopener noreferrer"
              className="bg-gray-800 text-white px-4 py-3 rounded-lg font-semibold hover:bg-gray-700 transition-all flex items-center justify-center gap-2"
            >
              <ExternalLink className="w-5 h-5" />
              View on Explorer
            </a>
          </div>

          <div className="bg-blue-50 rounded-lg p-3 border border-blue-200">
            <p className="text-xs text-blue-800">
              <strong>How it works:</strong> Your document was hashed using SHA-256 and the hash
              was recorded on the Polygon blockchain. Anyone can verify the document's authenticity
              by comparing its hash with the blockchain record.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
