import React from 'react';
import { Shield, CheckCircle } from 'lucide-react';

interface BlockchainBadgeProps {
  documentId: string;
  size?: 'sm' | 'md' | 'lg';
}

export const BlockchainBadge: React.FC<BlockchainBadgeProps> = ({ documentId, size = 'md' }) => {
  const [isVerified, setIsVerified] = React.useState(false);

  React.useEffect(() => {
    const record = localStorage.getItem(`blockchain_${documentId}`);
    setIsVerified(!!record);
  }, [documentId]);

  if (!isVerified) return null;

  const sizes = {
    sm: 'text-xs px-2 py-1',
    md: 'text-sm px-3 py-1.5',
    lg: 'text-base px-4 py-2'
  };

  const iconSizes = {
    sm: 'w-3 h-3',
    md: 'w-4 h-4',
    lg: 'w-5 h-5'
  };

  return (
    <div className={`inline-flex items-center gap-1.5 bg-gradient-to-r from-purple-100 to-blue-100 text-purple-900 rounded-full font-semibold border-2 border-purple-300 ${sizes[size]}`}>
      <Shield className={`${iconSizes[size]} text-purple-600`} />
      <span>Blockchain Verified</span>
      <CheckCircle className={`${iconSizes[size]} text-green-600`} />
    </div>
  );
};
