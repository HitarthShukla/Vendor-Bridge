import React, { useState, useRef, useEffect } from 'react';
import { MessageCircle, X, Send, Bot, User, Sparkles, TrendingUp, FileText, Users } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { toast } from 'sonner';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

export const AIChatbot: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      content: "👋 Hi! I'm your VendorBridge AI Assistant. I can help you with procurement tasks, vendor analysis, quotation comparisons, and more. What would you like to know?",
      timestamp: new Date()
    }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { user } = useAuth();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const quickActions = [
    { icon: TrendingUp, label: 'Vendor Analysis', prompt: 'Analyze vendor performance and suggest the best vendors' },
    { icon: FileText, label: 'Compare Quotes', prompt: 'Help me compare quotations for the latest RFQ' },
    { icon: Users, label: 'Vendor Insights', prompt: 'Give me insights about my vendor relationships' },
    { icon: Sparkles, label: 'Smart Suggestions', prompt: 'What procurement improvements can I make?' }
  ];

  const getAIResponse = async (userMessage: string): Promise<string> => {
    // Simulate AI response (In production, this would call Claude API)
    await new Promise(resolve => setTimeout(resolve, 1500));

    const lowerMessage = userMessage.toLowerCase();

    // Context-aware responses based on user role and query
    if (lowerMessage.includes('vendor') && lowerMessage.includes('best')) {
      return `Based on your procurement history:\n\n**Top Vendors:**\n1. **Acme Corp** - 4.8/5 rating, 95% on-time delivery\n2. **Global Supplies** - 4.7/5 rating, best pricing\n3. **Tech Solutions** - 4.6/5 rating, fastest delivery\n\n**Recommendation:** For urgent orders, use Tech Solutions. For cost optimization, choose Global Supplies.`;
    }

    if (lowerMessage.includes('quotation') || lowerMessage.includes('quote')) {
      return `📊 **Quotation Comparison Insights:**\n\n**RFQ Analysis:**\n- Average quote: $15,250\n- Lowest bid: $12,800 (Global Supplies)\n- Highest quality score: Acme Corp\n\n**AI Recommendation:**\n✅ Accept Global Supplies quotation\n- 16% below average\n- Good delivery timeline (7 days)\n- Reliable vendor (4.7★ rating)\n\n💡 Potential savings: $2,450`;
    }

    if (lowerMessage.includes('improve') || lowerMessage.includes('suggest')) {
      return `💡 **Smart Procurement Improvements:**\n\n1. **Cost Optimization**\n   - Bundle similar items to negotiate better rates\n   - Estimated savings: $5,000/month\n\n2. **Vendor Diversification**\n   - Currently 70% with one vendor\n   - Recommend adding 2-3 backup vendors\n\n3. **Process Automation**\n   - Auto-approve orders under $1,000\n   - Save 15 hours/week\n\n4. **Blockchain Integration**\n   - Enable immutable audit trails\n   - Increase transparency by 100%`;
    }

    if (lowerMessage.includes('blockchain') || lowerMessage.includes('verify')) {
      return `🔗 **Blockchain Features:**\n\n**What's Available:**\n✅ Document hashing for POs and invoices\n✅ Immutable audit trail\n✅ Cryptographic verification\n✅ Polygon Mumbai testnet integration\n\n**How to Use:**\n1. Generate a Purchase Order\n2. Click "Anchor to Blockchain"\n3. Transaction hash will be recorded\n4. Anyone can verify authenticity\n\n**Benefits:**\n- Tamper-proof records\n- Enhanced trust with vendors\n- Regulatory compliance\n- Dispute resolution`;
    }

    if (lowerMessage.includes('help') || lowerMessage.includes('how')) {
      return `🎯 **I can help you with:**\n\n**For ${user?.role === 'vendor' ? 'Vendors' : 'Procurement Officers'}:**\n${user?.role === 'vendor'
        ? '- View assigned RFQs\n- Submit competitive quotations\n- Track purchase orders\n- Manage your vendor profile'
        : '- Create and manage RFQs\n- Compare vendor quotations\n- Approve procurement requests\n- Generate purchase orders\n- Track vendor performance'
      }\n\n**AI-Powered:**\n- Smart vendor recommendations\n- Cost optimization insights\n- Risk analysis\n- Predictive analytics\n\n**Blockchain:**\n- Document verification\n- Immutable audit trails\n- Smart contract integration\n\nJust ask me anything!`;
    }

    // Default intelligent response
    return `I understand you're asking about "${userMessage}". \n\nAs your AI procurement assistant, I can help with:\n\n📊 **Analytics:** Vendor performance, spending patterns, cost optimization\n🤖 **Automation:** Smart recommendations, automated workflows\n🔍 **Insights:** Market trends, risk analysis, compliance\n⛓️ **Blockchain:** Document verification, audit trails\n\nCould you be more specific about what you'd like to know?`;
  };

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);

    try {
      const response = await getAIResponse(input);

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response,
        timestamp: new Date()
      };

      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      toast.error('Failed to get AI response');
    } finally {
      setIsTyping(false);
    }
  };

  const handleQuickAction = (prompt: string) => {
    setInput(prompt);
  };

  return (
    <>
      {/* Floating Chat Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-6 right-6 w-16 h-16 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-full shadow-2xl hover:shadow-3xl hover:scale-110 transition-all duration-300 flex items-center justify-center z-50 group"
      >
        {isOpen ? (
          <X className="w-7 h-7" />
        ) : (
          <div className="relative">
            <MessageCircle className="w-7 h-7" />
            <span className="absolute -top-1 -right-1 w-3 h-3 bg-green-400 rounded-full animate-pulse"></span>
          </div>
        )}

        {/* Tooltip */}
        <span className="absolute right-20 bg-gray-900 text-white text-sm px-3 py-2 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
          AI Assistant
        </span>
      </button>

      {/* Chat Window */}
      {isOpen && (
        <div className="fixed bottom-24 right-6 w-96 h-[600px] bg-white rounded-2xl shadow-2xl z-50 flex flex-col overflow-hidden border border-gray-200">
          {/* Header */}
          <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-4 flex items-center gap-3">
            <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm">
              <Bot className="w-6 h-6" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold">VendorBridge AI</h3>
              <p className="text-xs text-blue-100">Powered by Claude</p>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="hover:bg-white/20 p-2 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Quick Actions */}
          {messages.length === 1 && (
            <div className="p-4 border-b border-gray-200 bg-gradient-to-b from-blue-50 to-white">
              <p className="text-sm text-gray-600 mb-3 font-medium">Quick Actions:</p>
              <div className="grid grid-cols-2 gap-2">
                {quickActions.map((action, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleQuickAction(action.prompt)}
                    className="flex items-center gap-2 p-2 bg-white border border-gray-200 rounded-lg hover:border-blue-300 hover:bg-blue-50 transition-all text-left group"
                  >
                    <action.icon className="w-4 h-4 text-blue-600 group-hover:scale-110 transition-transform" />
                    <span className="text-xs text-gray-700 group-hover:text-blue-700">{action.label}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex gap-3 ${message.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}
              >
                <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                  message.role === 'user'
                    ? 'bg-blue-600 text-white'
                    : 'bg-gradient-to-br from-purple-500 to-blue-500 text-white'
                }`}>
                  {message.role === 'user' ? <User className="w-5 h-5" /> : <Bot className="w-5 h-5" />}
                </div>
                <div className={`flex-1 ${message.role === 'user' ? 'items-end' : 'items-start'} flex flex-col`}>
                  <div
                    className={`px-4 py-3 rounded-2xl max-w-[85%] ${
                      message.role === 'user'
                        ? 'bg-blue-600 text-white rounded-tr-none'
                        : 'bg-white text-gray-800 shadow-sm border border-gray-200 rounded-tl-none'
                    }`}
                  >
                    <p className="text-sm whitespace-pre-line leading-relaxed">{message.content}</p>
                  </div>
                  <span className="text-xs text-gray-400 mt-1 px-2">
                    {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
              </div>
            ))}

            {isTyping && (
              <div className="flex gap-3">
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-blue-500 text-white flex items-center justify-center flex-shrink-0">
                  <Bot className="w-5 h-5" />
                </div>
                <div className="bg-white text-gray-800 px-4 py-3 rounded-2xl rounded-tl-none shadow-sm border border-gray-200">
                  <div className="flex gap-1">
                    <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></span>
                    <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></span>
                    <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></span>
                  </div>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <div className="p-4 border-t border-gray-200 bg-white">
            <div className="flex gap-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Ask me anything..."
                className="flex-1 px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
              />
              <button
                onClick={handleSend}
                disabled={!input.trim() || isTyping}
                className="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-3 rounded-xl hover:shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Send className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
