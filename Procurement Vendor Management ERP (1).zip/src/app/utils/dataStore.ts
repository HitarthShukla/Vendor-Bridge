export interface Vendor {
  id: string;
  name: string;
  category: string;
  gstNumber: string;
  contactPerson: string;
  email: string;
  phone: string;
  address: string;
  status: 'active' | 'inactive';
  rating?: number;
  createdAt: string;
}

export interface RFQItem {
  id: string;
  productService: string;
  description: string;
  quantity: number;
  unit: string;
}

export interface RFQ {
  id: string;
  title: string;
  items: RFQItem[];
  deadline: string;
  assignedVendors: string[];
  status: 'draft' | 'sent' | 'closed';
  attachments?: string[];
  createdBy: string;
  createdAt: string;
}

export interface Quotation {
  id: string;
  rfqId: string;
  vendorId: string;
  items: {
    rfqItemId: string;
    unitPrice: number;
    totalPrice: number;
  }[];
  deliveryTimeline: string;
  notes: string;
  status: 'draft' | 'submitted' | 'accepted' | 'rejected';
  submittedAt?: string;
}

export interface ApprovalWorkflow {
  id: string;
  quotationId: string;
  rfqId: string;
  status: 'pending' | 'approved' | 'rejected';
  requestedBy: string;
  approver?: string;
  remarks?: string;
  createdAt: string;
  decidedAt?: string;
}

export interface PurchaseOrder {
  id: string;
  poNumber: string;
  quotationId: string;
  rfqId: string;
  vendorId: string;
  items: {
    productService: string;
    quantity: number;
    unitPrice: number;
    totalPrice: number;
  }[];
  subtotal: number;
  tax: number;
  total: number;
  status: 'draft' | 'sent' | 'completed';
  createdAt: string;
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  poId: string;
  vendorId: string;
  items: {
    productService: string;
    quantity: number;
    unitPrice: number;
    totalPrice: number;
  }[];
  subtotal: number;
  tax: number;
  total: number;
  status: 'draft' | 'sent' | 'paid';
  createdAt: string;
  sentAt?: string;
}

export interface ActivityLog {
  id: string;
  type: 'rfq_created' | 'quotation_submitted' | 'approval_requested' | 'approval_decided' | 'po_created' | 'invoice_generated' | 'invoice_sent';
  userId: string;
  userName: string;
  relatedId: string;
  relatedType: 'rfq' | 'quotation' | 'approval' | 'po' | 'invoice';
  message: string;
  timestamp: string;
}

class DataStore {
  private getItem<T>(key: string, defaultValue: T): T {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : defaultValue;
  }

  private setItem<T>(key: string, value: T): void {
    localStorage.setItem(key, JSON.stringify(value));
  }

  // Vendors
  getVendors(): Vendor[] {
    return this.getItem<Vendor[]>('vendors', []);
  }

  saveVendor(vendor: Vendor): void {
    const vendors = this.getVendors();
    const index = vendors.findIndex(v => v.id === vendor.id);
    if (index >= 0) {
      vendors[index] = vendor;
    } else {
      vendors.push(vendor);
    }
    this.setItem('vendors', vendors);
  }

  getVendorById(id: string): Vendor | undefined {
    return this.getVendors().find(v => v.id === id);
  }

  // RFQs
  getRFQs(): RFQ[] {
    return this.getItem<RFQ[]>('rfqs', []);
  }

  saveRFQ(rfq: RFQ): void {
    const rfqs = this.getRFQs();
    const index = rfqs.findIndex(r => r.id === rfq.id);
    if (index >= 0) {
      rfqs[index] = rfq;
    } else {
      rfqs.push(rfq);
    }
    this.setItem('rfqs', rfqs);
  }

  getRFQById(id: string): RFQ | undefined {
    return this.getRFQs().find(r => r.id === id);
  }

  // Quotations
  getQuotations(): Quotation[] {
    return this.getItem<Quotation[]>('quotations', []);
  }

  saveQuotation(quotation: Quotation): void {
    const quotations = this.getQuotations();
    const index = quotations.findIndex(q => q.id === quotation.id);
    if (index >= 0) {
      quotations[index] = quotation;
    } else {
      quotations.push(quotation);
    }
    this.setItem('quotations', quotations);
  }

  getQuotationById(id: string): Quotation | undefined {
    return this.getQuotations().find(q => q.id === id);
  }

  getQuotationsByRFQ(rfqId: string): Quotation[] {
    return this.getQuotations().filter(q => q.rfqId === rfqId);
  }

  getQuotationsByVendor(vendorId: string): Quotation[] {
    return this.getQuotations().filter(q => q.vendorId === vendorId);
  }

  // Approvals
  getApprovals(): ApprovalWorkflow[] {
    return this.getItem<ApprovalWorkflow[]>('approvals', []);
  }

  saveApproval(approval: ApprovalWorkflow): void {
    const approvals = this.getApprovals();
    const index = approvals.findIndex(a => a.id === approval.id);
    if (index >= 0) {
      approvals[index] = approval;
    } else {
      approvals.push(approval);
    }
    this.setItem('approvals', approvals);
  }

  getApprovalById(id: string): ApprovalWorkflow | undefined {
    return this.getApprovals().find(a => a.id === id);
  }

  // Purchase Orders
  getPurchaseOrders(): PurchaseOrder[] {
    return this.getItem<PurchaseOrder[]>('purchaseOrders', []);
  }

  savePurchaseOrder(po: PurchaseOrder): void {
    const pos = this.getPurchaseOrders();
    const index = pos.findIndex(p => p.id === po.id);
    if (index >= 0) {
      pos[index] = po;
    } else {
      pos.push(po);
    }
    this.setItem('purchaseOrders', pos);
  }

  getPOById(id: string): PurchaseOrder | undefined {
    return this.getPurchaseOrders().find(p => p.id === id);
  }

  // Invoices
  getInvoices(): Invoice[] {
    return this.getItem<Invoice[]>('invoices', []);
  }

  saveInvoice(invoice: Invoice): void {
    const invoices = this.getInvoices();
    const index = invoices.findIndex(i => i.id === invoice.id);
    if (index >= 0) {
      invoices[index] = invoice;
    } else {
      invoices.push(invoice);
    }
    this.setItem('invoices', invoices);
  }

  getInvoiceById(id: string): Invoice | undefined {
    return this.getInvoices().find(i => i.id === id);
  }

  // Activity Logs
  getActivityLogs(): ActivityLog[] {
    return this.getItem<ActivityLog[]>('activityLogs', []);
  }

  addActivityLog(log: Omit<ActivityLog, 'id' | 'timestamp'>): void {
    const logs = this.getActivityLogs();
    logs.unshift({
      ...log,
      id: Date.now().toString(),
      timestamp: new Date().toISOString()
    });
    this.setItem('activityLogs', logs);
  }

  // Initialize with demo data
  initializeDemoData(): void {
    if (!localStorage.getItem('dataInitialized')) {
      // Demo vendors
      const demoVendors: Vendor[] = [
        {
          id: 'V001',
          name: 'TechSupply Corp',
          category: 'Electronics',
          gstNumber: 'GST123456789',
          contactPerson: 'John Smith',
          email: 'john@techsupply.com',
          phone: '+1-555-0100',
          address: '123 Tech Street, Silicon Valley, CA',
          status: 'active',
          rating: 4.5,
          createdAt: new Date().toISOString()
        },
        {
          id: 'V002',
          name: 'Office Solutions Ltd',
          category: 'Office Supplies',
          gstNumber: 'GST987654321',
          contactPerson: 'Jane Doe',
          email: 'jane@officesolutions.com',
          phone: '+1-555-0200',
          address: '456 Business Ave, New York, NY',
          status: 'active',
          rating: 4.2,
          createdAt: new Date().toISOString()
        }
      ];

      this.setItem('vendors', demoVendors);
      localStorage.setItem('dataInitialized', 'true');
    }
  }
}

export const dataStore = new DataStore();
