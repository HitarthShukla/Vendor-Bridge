import React, { useState } from 'react';
import { dataStore, ApprovalWorkflow } from '../utils/dataStore';
import { useAuth } from '../contexts/AuthContext';
import { CheckCircle, XCircle, Clock, MessageSquare } from 'lucide-react';
import { toast } from 'sonner';
import { useNavigate } from 'react-router';

export const ApprovalsPage: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [approvals, setApprovals] = useState<ApprovalWorkflow[]>(dataStore.getApprovals());
  const [selectedApproval, setSelectedApproval] = useState<ApprovalWorkflow | null>(null);
  const [remarks, setRemarks] = useState('');
  const [filter, setFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('pending');

  const filteredApprovals = filter === 'all'
    ? approvals
    : approvals.filter(a => a.status === filter);

  const handleApprove = (approval: ApprovalWorkflow) => {
    const updatedApproval = {
      ...approval,
      status: 'approved' as const,
      approver: user?.id,
      remarks,
      decidedAt: new Date().toISOString()
    };

    dataStore.saveApproval(updatedApproval);
    setApprovals(dataStore.getApprovals());

    const quotation = dataStore.getQuotationById(approval.quotationId);
    const rfq = dataStore.getRFQById(approval.rfqId);

    if (quotation && rfq) {
      const rfqItems = rfq.items.map(item => {
        const quotItem = quotation.items.find(q => q.rfqItemId === item.id);
        return {
          productService: item.productService,
          quantity: item.quantity,
          unitPrice: quotItem?.unitPrice || 0,
          totalPrice: quotItem?.totalPrice || 0
        };
      });

      const subtotal = rfqItems.reduce((sum, item) => sum + item.totalPrice, 0);
      const tax = subtotal * 0.18;

      const po = {
        id: `PO${Date.now()}`,
        poNumber: `PO-${Date.now().toString().slice(-6)}`,
        quotationId: quotation.id,
        rfqId: rfq.id,
        vendorId: quotation.vendorId,
        items: rfqItems,
        subtotal,
        tax,
        total: subtotal + tax,
        status: 'draft' as const,
        createdAt: new Date().toISOString()
      };

      dataStore.savePurchaseOrder(po);

      dataStore.addActivityLog({
        type: 'po_created',
        userId: user?.id || '',
        userName: user?.name || '',
        relatedId: po.id,
        relatedType: 'po',
        message: `Approved quotation and created PO: ${po.poNumber}`
      });
    }

    dataStore.addActivityLog({
      type: 'approval_decided',
      userId: user?.id || '',
      userName: user?.name || '',
      relatedId: approval.id,
      relatedType: 'approval',
      message: `Approved procurement request`
    });

    toast.success('Approval granted! Purchase Order created.');
    setSelectedApproval(null);
    setRemarks('');
  };

  const handleReject = (approval: ApprovalWorkflow) => {
    if (!remarks.trim()) {
      toast.error('Please provide remarks for rejection');
      return;
    }

    const updatedApproval = {
      ...approval,
      status: 'rejected' as const,
      approver: user?.id,
      remarks,
      decidedAt: new Date().toISOString()
    };

    dataStore.saveApproval(updatedApproval);
    setApprovals(dataStore.getApprovals());

    dataStore.addActivityLog({
      type: 'approval_decided',
      userId: user?.id || '',
      userName: user?.name || '',
      relatedId: approval.id,
      relatedType: 'approval',
      message: `Rejected procurement request: ${remarks}`
    });

    toast.success('Approval rejected');
    setSelectedApproval(null);
    setRemarks('');
  };

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Approval Workflow</h1>
        <p className="text-gray-600">Review and approve procurement requests</p>
      </div>

      {/* Filter Tabs */}
      <div className="bg-white rounded-lg shadow mb-6">
        <div className="flex border-b border-gray-200">
          {(['all', 'pending', 'approved', 'rejected'] as const).map((status) => (
            <button
              key={status}
              onClick={() => setFilter(status)}
              className={`px-6 py-3 font-medium transition-colors ${
                filter === status
                  ? 'text-blue-600 border-b-2 border-blue-600'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              {status.charAt(0).toUpperCase() + status.slice(1)}
              {status !== 'all' && (
                <span className="ml-2 text-sm">
                  ({approvals.filter(a => a.status === status).length})
                </span>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Approvals List */}
      <div className="space-y-4">
        {filteredApprovals.map((approval) => {
          const quotation = dataStore.getQuotationById(approval.quotationId);
          const rfq = dataStore.getRFQById(approval.rfqId);
          const vendor = quotation ? dataStore.getVendorById(quotation.vendorId) : null;
          const total = quotation?.items.reduce((sum, item) => sum + item.totalPrice, 0) || 0;

          return (
            <div key={approval.id} className="bg-white rounded-lg shadow p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="text-lg font-semibold text-gray-900">{rfq?.title}</h3>
                    <span className={`px-2 py-1 rounded-full text-xs ${
                      approval.status === 'approved' ? 'bg-green-100 text-green-800' :
                      approval.status === 'rejected' ? 'bg-red-100 text-red-800' :
                      'bg-yellow-100 text-yellow-800'
                    }`}>
                      {approval.status}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                    <div>
                      <p className="text-sm text-gray-600">Approval ID</p>
                      <p className="font-medium text-gray-900">{approval.id}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Vendor</p>
                      <p className="font-medium text-gray-900">{vendor?.name || 'N/A'}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Amount</p>
                      <p className="font-medium text-gray-900">${total.toFixed(2)}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Delivery</p>
                      <p className="font-medium text-gray-900">{quotation?.deliveryTimeline || 'N/A'}</p>
                    </div>
                  </div>

                  <div className="mb-4">
                    <p className="text-sm text-gray-600">Requested: {new Date(approval.createdAt).toLocaleString()}</p>
                    {approval.decidedAt && (
                      <p className="text-sm text-gray-600">Decided: {new Date(approval.decidedAt).toLocaleString()}</p>
                    )}
                  </div>

                  {approval.remarks && (
                    <div className="bg-gray-50 rounded-lg p-3 mb-4">
                      <p className="text-sm font-medium text-gray-700 mb-1">Remarks:</p>
                      <p className="text-sm text-gray-600">{approval.remarks}</p>
                    </div>
                  )}

                  {approval.status === 'pending' && (
                    <div className="flex gap-3">
                      <button
                        onClick={() => setSelectedApproval(approval)}
                        className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                      >
                        Review & Decide
                      </button>
                    </div>
                  )}
                </div>
              </div>

              {/* Items Summary */}
              {quotation && rfq && (
                <div className="border-t border-gray-200 pt-4">
                  <h4 className="font-medium text-gray-900 mb-2">Items:</h4>
                  <div className="space-y-1">
                    {quotation.items.map((item) => {
                      const rfqItem = rfq.items.find(i => i.id === item.rfqItemId);
                      return (
                        <div key={item.rfqItemId} className="flex justify-between text-sm">
                          <span className="text-gray-600">{rfqItem?.productService}</span>
                          <span className="font-medium text-gray-900">${item.totalPrice.toFixed(2)}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          );
        })}

        {filteredApprovals.length === 0 && (
          <div className="text-center py-12 bg-white rounded-lg shadow">
            <Clock className="w-12 h-12 text-gray-400 mx-auto mb-3" />
            <p className="text-gray-500">No {filter !== 'all' ? filter : ''} approvals found</p>
          </div>
        )}
      </div>

      {/* Approval Decision Modal */}
      {selectedApproval && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-2xl w-full p-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Review Approval Request</h2>

            {(() => {
              const quotation = dataStore.getQuotationById(selectedApproval.quotationId);
              const rfq = dataStore.getRFQById(selectedApproval.rfqId);
              const vendor = quotation ? dataStore.getVendorById(quotation.vendorId) : null;
              const total = quotation?.items.reduce((sum, item) => sum + item.totalPrice, 0) || 0;

              return (
                <div className="space-y-4 mb-6">
                  <div className="grid grid-cols-2 gap-4 p-4 bg-gray-50 rounded-lg">
                    <div>
                      <p className="text-sm text-gray-600">RFQ</p>
                      <p className="font-medium text-gray-900">{rfq?.title}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Vendor</p>
                      <p className="font-medium text-gray-900">{vendor?.name}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Total Amount</p>
                      <p className="text-xl font-bold text-gray-900">${total.toFixed(2)}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Delivery Timeline</p>
                      <p className="font-medium text-gray-900">{quotation?.deliveryTimeline}</p>
                    </div>
                  </div>

                  {quotation?.notes && (
                    <div className="p-4 bg-blue-50 rounded-lg">
                      <p className="text-sm font-medium text-gray-700 mb-1">Vendor Notes:</p>
                      <p className="text-sm text-gray-600">{quotation.notes}</p>
                    </div>
                  )}
                </div>
              );
            })()}

            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Remarks (required for rejection)
              </label>
              <textarea
                value={remarks}
                onChange={(e) => setRemarks(e.target.value)}
                rows={4}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                placeholder="Add your comments or reasons for the decision..."
              />
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => {
                  setSelectedApproval(null);
                  setRemarks('');
                }}
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={() => handleReject(selectedApproval)}
                className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
              >
                <XCircle className="w-4 h-4" />
                Reject
              </button>
              <button
                onClick={() => handleApprove(selectedApproval)}
                className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
              >
                <CheckCircle className="w-4 h-4" />
                Approve
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
