import React, { useState } from 'react';
import { dataStore, RFQ, RFQItem } from '../utils/dataStore';
import { useAuth } from '../contexts/AuthContext';
import { Plus, Search, Eye, Send, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { useNavigate } from 'react-router';

export const RFQsPage: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [rfqs, setRfqs] = useState<RFQ[]>(dataStore.getRFQs());
  const [showModal, setShowModal] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  const [formData, setFormData] = useState({
    title: '',
    deadline: '',
    assignedVendors: [] as string[],
  });

  const [items, setItems] = useState<RFQItem[]>([
    { id: '1', productService: '', description: '', quantity: 0, unit: 'pcs' }
  ]);

  const vendors = dataStore.getVendors().filter(v => v.status === 'active');

  const displayRfqs = user?.role === 'vendor'
    ? rfqs.filter(r => r.assignedVendors.includes(user.vendorId || ''))
    : rfqs;

  const filteredRfqs = displayRfqs.filter(rfq =>
    rfq.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleAddItem = () => {
    setItems([...items, {
      id: Date.now().toString(),
      productService: '',
      description: '',
      quantity: 0,
      unit: 'pcs'
    }]);
  };

  const handleRemoveItem = (id: string) => {
    setItems(items.filter(item => item.id !== id));
  };

  const handleItemChange = (id: string, field: keyof RFQItem, value: string | number) => {
    setItems(items.map(item =>
      item.id === id ? { ...item, [field]: value } : item
    ));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const rfq: RFQ = {
      id: `RFQ${Date.now()}`,
      ...formData,
      items: items.filter(item => item.productService && item.quantity > 0),
      status: 'draft',
      createdBy: user?.id || '',
      createdAt: new Date().toISOString()
    };

    dataStore.saveRFQ(rfq);
    setRfqs(dataStore.getRFQs());

    dataStore.addActivityLog({
      type: 'rfq_created',
      userId: user?.id || '',
      userName: user?.name || '',
      relatedId: rfq.id,
      relatedType: 'rfq',
      message: `Created RFQ: ${rfq.title}`
    });

    toast.success('RFQ created successfully!');
    setShowModal(false);
    resetForm();
  };

  const handleSendRFQ = (rfq: RFQ) => {
    const updatedRfq = { ...rfq, status: 'sent' as const };
    dataStore.saveRFQ(updatedRfq);
    setRfqs(dataStore.getRFQs());

    dataStore.addActivityLog({
      type: 'rfq_created',
      userId: user?.id || '',
      userName: user?.name || '',
      relatedId: rfq.id,
      relatedType: 'rfq',
      message: `Sent RFQ to ${rfq.assignedVendors.length} vendor(s): ${rfq.title}`
    });

    toast.success('RFQ sent to vendors!');
  };

  const resetForm = () => {
    setFormData({
      title: '',
      deadline: '',
      assignedVendors: [],
    });
    setItems([{ id: '1', productService: '', description: '', quantity: 0, unit: 'pcs' }]);
  };

  const toggleVendor = (vendorId: string) => {
    setFormData(prev => ({
      ...prev,
      assignedVendors: prev.assignedVendors.includes(vendorId)
        ? prev.assignedVendors.filter(id => id !== vendorId)
        : [...prev.assignedVendors, vendorId]
    }));
  };

  const canCreateRFQ = user?.role === 'procurement_officer' || user?.role === 'admin';

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Request for Quotations</h1>
          <p className="text-gray-600">
            {user?.role === 'vendor' ? 'View and respond to RFQs' : 'Create and manage RFQs'}
          </p>
        </div>
        {canCreateRFQ && (
          <button
            onClick={() => setShowModal(true)}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            <Plus className="w-5 h-5" />
            Create RFQ
          </button>
        )}
      </div>

      {/* Search */}
      <div className="bg-white rounded-lg shadow p-4 mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Search RFQs..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg"
          />
        </div>
      </div>

      {/* RFQs List */}
      <div className="space-y-4">
        {filteredRfqs.map((rfq) => {
          const quotations = dataStore.getQuotationsByRFQ(rfq.id);
          const userQuotation = user?.vendorId
            ? quotations.find(q => q.vendorId === user.vendorId)
            : null;

          return (
            <div key={rfq.id} className="bg-white rounded-lg shadow p-6">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="text-xl font-semibold text-gray-900">{rfq.title}</h3>
                    <span className={`px-2 py-1 rounded-full text-xs ${
                      rfq.status === 'sent' ? 'bg-blue-100 text-blue-800' :
                      rfq.status === 'closed' ? 'bg-gray-100 text-gray-800' :
                      'bg-yellow-100 text-yellow-800'
                    }`}>
                      {rfq.status}
                    </span>
                  </div>
                  <p className="text-sm text-gray-600">RFQ ID: {rfq.id}</p>
                  <p className="text-sm text-gray-600">
                    Deadline: {new Date(rfq.deadline).toLocaleDateString()}
                  </p>
                </div>

                <div className="flex gap-2">
                  {user?.role === 'vendor' && rfq.status === 'sent' && (
                    <button
                      onClick={() => navigate(`/quotations?rfq=${rfq.id}`)}
                      className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                    >
                      {userQuotation ? 'View Quotation' : 'Submit Quotation'}
                    </button>
                  )}
                  {canCreateRFQ && rfq.status === 'draft' && (
                    <button
                      onClick={() => handleSendRFQ(rfq)}
                      className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
                    >
                      <Send className="w-4 h-4" />
                      Send to Vendors
                    </button>
                  )}
                  {canCreateRFQ && rfq.status === 'sent' && (
                    <button
                      onClick={() => navigate(`/quotations?compare=${rfq.id}`)}
                      className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700"
                    >
                      Compare Quotations ({quotations.length})
                    </button>
                  )}
                </div>
              </div>

              <div className="border-t border-gray-200 pt-4">
                <h4 className="font-medium text-gray-900 mb-2">Items:</h4>
                <div className="space-y-2">
                  {rfq.items.map((item) => (
                    <div key={item.id} className="flex items-center justify-between text-sm">
                      <span className="text-gray-900">{item.productService}</span>
                      <span className="text-gray-600">{item.quantity} {item.unit}</span>
                    </div>
                  ))}
                </div>
              </div>

              {canCreateRFQ && (
                <div className="border-t border-gray-200 pt-4 mt-4">
                  <p className="text-sm text-gray-600">
                    Assigned to {rfq.assignedVendors.length} vendor(s)
                  </p>
                </div>
              )}
            </div>
          );
        })}

        {filteredRfqs.length === 0 && (
          <div className="text-center py-12 bg-white rounded-lg shadow">
            <p className="text-gray-500">No RFQs found</p>
          </div>
        )}
      </div>

      {/* Create RFQ Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto p-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Create New RFQ</h2>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  RFQ Title *
                </label>
                <input
                  type="text"
                  required
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                  placeholder="e.g., Office Supplies Procurement Q2 2026"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Deadline *
                </label>
                <input
                  type="date"
                  required
                  value={formData.deadline}
                  onChange={(e) => setFormData({ ...formData, deadline: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                />
              </div>

              {/* Items */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <label className="block text-sm font-medium text-gray-700">
                    Items *
                  </label>
                  <button
                    type="button"
                    onClick={handleAddItem}
                    className="text-sm text-blue-600 hover:text-blue-700"
                  >
                    + Add Item
                  </button>
                </div>

                <div className="space-y-3">
                  {items.map((item, index) => (
                    <div key={item.id} className="grid grid-cols-12 gap-3 p-3 border border-gray-200 rounded-lg">
                      <div className="col-span-4">
                        <input
                          type="text"
                          placeholder="Product/Service"
                          value={item.productService}
                          onChange={(e) => handleItemChange(item.id, 'productService', e.target.value)}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                        />
                      </div>
                      <div className="col-span-4">
                        <input
                          type="text"
                          placeholder="Description"
                          value={item.description}
                          onChange={(e) => handleItemChange(item.id, 'description', e.target.value)}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                        />
                      </div>
                      <div className="col-span-2">
                        <input
                          type="number"
                          placeholder="Qty"
                          min="0"
                          value={item.quantity || ''}
                          onChange={(e) => handleItemChange(item.id, 'quantity', parseInt(e.target.value) || 0)}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                        />
                      </div>
                      <div className="col-span-1">
                        <input
                          type="text"
                          placeholder="Unit"
                          value={item.unit}
                          onChange={(e) => handleItemChange(item.id, 'unit', e.target.value)}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                        />
                      </div>
                      <div className="col-span-1 flex items-center">
                        {items.length > 1 && (
                          <button
                            type="button"
                            onClick={() => handleRemoveItem(item.id)}
                            className="p-2 text-red-600 hover:bg-red-50 rounded"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Assign Vendors */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">
                  Assign Vendors *
                </label>
                <div className="grid grid-cols-2 gap-2 max-h-60 overflow-y-auto border border-gray-200 rounded-lg p-3">
                  {vendors.map((vendor) => (
                    <label key={vendor.id} className="flex items-center gap-2 p-2 hover:bg-gray-50 rounded cursor-pointer">
                      <input
                        type="checkbox"
                        checked={formData.assignedVendors.includes(vendor.id)}
                        onChange={() => toggleVendor(vendor.id)}
                        className="w-4 h-4"
                      />
                      <div>
                        <p className="text-sm font-medium text-gray-900">{vendor.name}</p>
                        <p className="text-xs text-gray-600">{vendor.category}</p>
                      </div>
                    </label>
                  ))}
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => {
                    setShowModal(false);
                    resetForm();
                  }}
                  className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  Create RFQ
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
