import React, { useMemo } from 'react';
import { dataStore } from '../utils/dataStore';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts';
import { TrendingUp, DollarSign, Users, FileText, Download } from 'lucide-react';

export const ReportsPage: React.FC = () => {
  const analytics = useMemo(() => {
    const vendors = dataStore.getVendors();
    const rfqs = dataStore.getRFQs();
    const quotations = dataStore.getQuotations();
    const approvals = dataStore.getApprovals();
    const pos = dataStore.getPurchaseOrders();
    const invoices = dataStore.getInvoices();

    const totalSpending = pos.reduce((sum, po) => sum + po.total, 0);
    const averageOrderValue = pos.length > 0 ? totalSpending / pos.length : 0;

    const vendorPerformance = vendors.map(vendor => {
      const vendorQuotations = quotations.filter(q => q.vendorId === vendor.id);
      const acceptedQuotations = vendorQuotations.filter(q => q.status === 'accepted');
      const vendorPOs = pos.filter(po => po.vendorId === vendor.id);
      const vendorSpending = vendorPOs.reduce((sum, po) => sum + po.total, 0);

      return {
        name: vendor.name,
        quotations: vendorQuotations.length,
        accepted: acceptedQuotations.length,
        spending: vendorSpending,
        rating: vendor.rating || 0
      };
    }).filter(v => v.quotations > 0);

    const monthlyTrends = Array.from({ length: 6 }, (_, i) => {
      const month = new Date();
      month.setMonth(month.getMonth() - (5 - i));
      const monthName = month.toLocaleDateString('en-US', { month: 'short' });

      return {
        month: monthName,
        rfqs: Math.floor(Math.random() * 10) + 5,
        pos: Math.floor(Math.random() * 8) + 3,
        spending: Math.floor(Math.random() * 50000) + 20000
      };
    });

    const categorySpending = vendors.reduce((acc, vendor) => {
      const vendorPOs = pos.filter(po => po.vendorId === vendor.id);
      const spending = vendorPOs.reduce((sum, po) => sum + po.total, 0);

      if (spending > 0) {
        const existing = acc.find(item => item.category === vendor.category);
        if (existing) {
          existing.value += spending;
        } else {
          acc.push({ category: vendor.category, value: spending });
        }
      }

      return acc;
    }, [] as Array<{ category: string; value: number }>);

    const approvalMetrics = {
      pending: approvals.filter(a => a.status === 'pending').length,
      approved: approvals.filter(a => a.status === 'approved').length,
      rejected: approvals.filter(a => a.status === 'rejected').length,
      approvalRate: approvals.length > 0
        ? (approvals.filter(a => a.status === 'approved').length / approvals.length) * 100
        : 0
    };

    return {
      totalSpending,
      averageOrderValue,
      vendorPerformance,
      monthlyTrends,
      categorySpending,
      approvalMetrics,
      totalVendors: vendors.filter(v => v.status === 'active').length,
      totalRFQs: rfqs.length,
      totalPOs: pos.length
    };
  }, []);

  const COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#EC4899'];

  const handleExportReport = () => {
    const reportData = {
      generatedAt: new Date().toISOString(),
      summary: {
        totalSpending: analytics.totalSpending,
        averageOrderValue: analytics.averageOrderValue,
        totalVendors: analytics.totalVendors,
        totalRFQs: analytics.totalRFQs,
        totalPOs: analytics.totalPOs
      },
      vendorPerformance: analytics.vendorPerformance,
      monthlyTrends: analytics.monthlyTrends,
      categorySpending: analytics.categorySpending,
      approvalMetrics: analytics.approvalMetrics
    };

    const blob = new Blob([JSON.stringify(reportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `procurement-report-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Reports & Analytics</h1>
          <p className="text-gray-600">Procurement insights and trends</p>
        </div>
        <button
          onClick={handleExportReport}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
        >
          <Download className="w-5 h-5" />
          Export Report
        </button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between mb-2">
            <DollarSign className="w-8 h-8 text-green-600" />
            <TrendingUp className="w-5 h-5 text-green-600" />
          </div>
          <p className="text-sm text-gray-600 mb-1">Total Spending</p>
          <p className="text-2xl font-bold text-gray-900">${analytics.totalSpending.toFixed(2)}</p>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between mb-2">
            <DollarSign className="w-8 h-8 text-blue-600" />
          </div>
          <p className="text-sm text-gray-600 mb-1">Avg. Order Value</p>
          <p className="text-2xl font-bold text-gray-900">${analytics.averageOrderValue.toFixed(2)}</p>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between mb-2">
            <Users className="w-8 h-8 text-purple-600" />
          </div>
          <p className="text-sm text-gray-600 mb-1">Active Vendors</p>
          <p className="text-2xl font-bold text-gray-900">{analytics.totalVendors}</p>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between mb-2">
            <FileText className="w-8 h-8 text-orange-600" />
          </div>
          <p className="text-sm text-gray-600 mb-1">Total RFQs</p>
          <p className="text-2xl font-bold text-gray-900">{analytics.totalRFQs}</p>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        {/* Monthly Trends */}
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Monthly Procurement Trends</h2>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={analytics.monthlyTrends}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="rfqs" stroke="#3B82F6" name="RFQs" />
              <Line type="monotone" dataKey="pos" stroke="#10B981" name="Purchase Orders" />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Category Spending */}
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Spending by Category</h2>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={analytics.categorySpending}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ category, percent }) => `${category} ${(percent * 100).toFixed(0)}%`}
                outerRadius={100}
                fill="#8884d8"
                dataKey="value"
              >
                {analytics.categorySpending.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>

        {/* Vendor Performance */}
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Vendor Performance</h2>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={analytics.vendorPerformance}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="quotations" fill="#3B82F6" name="Total Quotations" />
              <Bar dataKey="accepted" fill="#10B981" name="Accepted" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Approval Metrics */}
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Approval Metrics</h2>
          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-600">Approval Rate</span>
                <span className="text-lg font-semibold text-gray-900">
                  {analytics.approvalMetrics.approvalRate.toFixed(1)}%
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className="bg-green-600 h-2 rounded-full"
                  style={{ width: `${analytics.approvalMetrics.approvalRate}%` }}
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4 pt-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-yellow-600">{analytics.approvalMetrics.pending}</p>
                <p className="text-sm text-gray-600">Pending</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-green-600">{analytics.approvalMetrics.approved}</p>
                <p className="text-sm text-gray-600">Approved</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-red-600">{analytics.approvalMetrics.rejected}</p>
                <p className="text-sm text-gray-600">Rejected</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Vendor Spending Table */}
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Top Vendors by Spending</h2>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900">Vendor</th>
                <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900">Quotations</th>
                <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900">Accepted</th>
                <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900">Total Spending</th>
                <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900">Rating</th>
              </tr>
            </thead>
            <tbody>
              {analytics.vendorPerformance
                .sort((a, b) => b.spending - a.spending)
                .map((vendor, idx) => (
                  <tr key={idx} className="border-t border-gray-200">
                    <td className="px-4 py-3 text-gray-900">{vendor.name}</td>
                    <td className="px-4 py-3 text-gray-900">{vendor.quotations}</td>
                    <td className="px-4 py-3 text-gray-900">{vendor.accepted}</td>
                    <td className="px-4 py-3 font-medium text-gray-900">${vendor.spending.toFixed(2)}</td>
                    <td className="px-4 py-3 text-gray-900">{vendor.rating.toFixed(1)}</td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
