import React, { useMemo } from 'react';
import { Link } from 'react-router';
import { useAuth } from '../contexts/AuthContext';
import { dataStore } from '../utils/dataStore';
import {
  FileText,
  ClipboardList,
  CheckSquare,
  FileCheck,
  TrendingUp,
  Clock,
  DollarSign,
  Users
} from 'lucide-react';

export const DashboardPage: React.FC = () => {
  const { user } = useAuth();

  const stats = useMemo(() => {
    const rfqs = dataStore.getRFQs();
    const quotations = dataStore.getQuotations();
    const approvals = dataStore.getApprovals();
    const pos = dataStore.getPurchaseOrders();
    const invoices = dataStore.getInvoices();

    if (user?.role === 'vendor') {
      const vendorQuotations = quotations.filter(q => q.vendorId === user.vendorId);
      const vendorRFQs = rfqs.filter(r => r.assignedVendors.includes(user.vendorId || ''));

      return [
        { label: 'Assigned RFQs', value: vendorRFQs.length, icon: FileText, color: 'blue' },
        { label: 'My Quotations', value: vendorQuotations.length, icon: ClipboardList, color: 'green' },
        { label: 'Accepted Quotes', value: vendorQuotations.filter(q => q.status === 'accepted').length, icon: CheckSquare, color: 'purple' },
        { label: 'Purchase Orders', value: pos.filter(p => p.vendorId === user.vendorId).length, icon: FileCheck, color: 'orange' },
      ];
    }

    if (user?.role === 'manager') {
      return [
        { label: 'Pending Approvals', value: approvals.filter(a => a.status === 'pending').length, icon: Clock, color: 'yellow' },
        { label: 'Approved', value: approvals.filter(a => a.status === 'approved').length, icon: CheckSquare, color: 'green' },
        { label: 'Total RFQs', value: rfqs.length, icon: FileText, color: 'blue' },
        { label: 'Total POs', value: pos.length, icon: FileCheck, color: 'purple' },
      ];
    }

    return [
      { label: 'Active RFQs', value: rfqs.filter(r => r.status === 'sent').length, icon: FileText, color: 'blue' },
      { label: 'Quotations', value: quotations.length, icon: ClipboardList, color: 'green' },
      { label: 'Purchase Orders', value: pos.length, icon: FileCheck, color: 'purple' },
      { label: 'Invoices', value: invoices.length, icon: DollarSign, color: 'orange' },
    ];
  }, [user]);

  const recentActivity = useMemo(() => {
    const logs = dataStore.getActivityLogs();
    return logs.slice(0, 5);
  }, []);

  const quickActions = useMemo(() => {
    if (user?.role === 'vendor') {
      return [
        { label: 'View RFQs', path: '/rfqs', icon: FileText },
        { label: 'My Quotations', path: '/quotations', icon: ClipboardList },
      ];
    }

    if (user?.role === 'manager') {
      return [
        { label: 'Pending Approvals', path: '/approvals', icon: CheckSquare },
        { label: 'View Reports', path: '/reports', icon: TrendingUp },
      ];
    }

    return [
      { label: 'Create RFQ', path: '/rfqs', icon: FileText },
      { label: 'Manage Vendors', path: '/vendors', icon: Users },
      { label: 'Purchase Orders', path: '/purchase-orders', icon: FileCheck },
      { label: 'View Reports', path: '/reports', icon: TrendingUp },
    ];
  }, [user]);

  const colorMap = {
    blue: 'bg-blue-500',
    green: 'bg-green-500',
    purple: 'bg-purple-500',
    orange: 'bg-orange-500',
    yellow: 'bg-yellow-500'
  };

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Dashboard</h1>
        <p className="text-gray-600">Welcome back, {user?.name}</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center justify-between mb-4">
                <div className={`p-3 rounded-lg ${colorMap[stat.color as keyof typeof colorMap]}`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <span className="text-3xl font-bold text-gray-900">{stat.value}</span>
              </div>
              <p className="text-gray-600">{stat.label}</p>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Quick Actions */}
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Quick Actions</h2>
          <div className="space-y-3">
            {quickActions.map((action, index) => {
              const Icon = action.icon;
              return (
                <Link
                  key={index}
                  to={action.path}
                  className="flex items-center gap-3 p-3 rounded-lg border border-gray-200 hover:bg-gray-50 transition-colors"
                >
                  <Icon className="w-5 h-5 text-blue-600" />
                  <span className="font-medium text-gray-900">{action.label}</span>
                </Link>
              );
            })}
          </div>
        </div>

        {/* Recent Activity */}
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Recent Activity</h2>
          {recentActivity.length > 0 ? (
            <div className="space-y-4">
              {recentActivity.map((log) => (
                <div key={log.id} className="flex gap-3">
                  <div className="w-2 h-2 mt-2 rounded-full bg-blue-500 flex-shrink-0" />
                  <div>
                    <p className="text-gray-900">{log.message}</p>
                    <p className="text-sm text-gray-500">
                      {new Date(log.timestamp).toLocaleString()}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-500">No recent activity</p>
          )}
        </div>
      </div>
    </div>
  );
};
