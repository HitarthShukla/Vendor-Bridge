import React, { useState, useMemo } from 'react';
import { dataStore, ActivityLog } from '../utils/dataStore';
import { Activity, FileText, ClipboardList, CheckSquare, FileCheck, DollarSign, Mail, Filter } from 'lucide-react';

export const ActivityLogsPage: React.FC = () => {
  const [logs, setLogs] = useState<ActivityLog[]>(dataStore.getActivityLogs());
  const [filterType, setFilterType] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredLogs = useMemo(() => {
    return logs.filter(log => {
      const matchesType = filterType === 'all' || log.type === filterType;
      const matchesSearch = log.message.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           log.userName.toLowerCase().includes(searchTerm.toLowerCase());
      return matchesType && matchesSearch;
    });
  }, [logs, filterType, searchTerm]);

  const activityTypes = [
    { value: 'all', label: 'All Activities' },
    { value: 'rfq_created', label: 'RFQ Created' },
    { value: 'quotation_submitted', label: 'Quotation Submitted' },
    { value: 'approval_requested', label: 'Approval Requested' },
    { value: 'approval_decided', label: 'Approval Decided' },
    { value: 'po_created', label: 'PO Created' },
    { value: 'invoice_generated', label: 'Invoice Generated' },
    { value: 'invoice_sent', label: 'Invoice Sent' },
  ];

  const getIcon = (type: string) => {
    switch (type) {
      case 'rfq_created': return FileText;
      case 'quotation_submitted': return ClipboardList;
      case 'approval_requested':
      case 'approval_decided': return CheckSquare;
      case 'po_created': return FileCheck;
      case 'invoice_generated': return DollarSign;
      case 'invoice_sent': return Mail;
      default: return Activity;
    }
  };

  const getColor = (type: string) => {
    switch (type) {
      case 'rfq_created': return 'blue';
      case 'quotation_submitted': return 'green';
      case 'approval_requested': return 'yellow';
      case 'approval_decided': return 'purple';
      case 'po_created': return 'indigo';
      case 'invoice_generated': return 'orange';
      case 'invoice_sent': return 'pink';
      default: return 'gray';
    }
  };

  const colorClasses = {
    blue: 'bg-blue-100 text-blue-600',
    green: 'bg-green-100 text-green-600',
    yellow: 'bg-yellow-100 text-yellow-600',
    purple: 'bg-purple-100 text-purple-600',
    indigo: 'bg-indigo-100 text-indigo-600',
    orange: 'bg-orange-100 text-orange-600',
    pink: 'bg-pink-100 text-pink-600',
    gray: 'bg-gray-100 text-gray-600',
  };

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Activity Logs & Notifications</h1>
        <p className="text-gray-600">Track all procurement activities and updates</p>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-lg shadow p-6 mb-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Filter by Type
            </label>
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg"
            >
              {activityTypes.map(type => (
                <option key={type.value} value={type.value}>{type.label}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Search
            </label>
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search activities..."
              className="w-full px-3 py-2 border border-gray-300 rounded-lg"
            />
          </div>
        </div>
      </div>

      {/* Activity Timeline */}
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-6">Activity Timeline</h2>

        {filteredLogs.length > 0 ? (
          <div className="space-y-4">
            {filteredLogs.map((log) => {
              const Icon = getIcon(log.type);
              const color = getColor(log.type);

              return (
                <div key={log.id} className="flex gap-4">
                  <div className={`flex-shrink-0 w-10 h-10 rounded-full ${colorClasses[color as keyof typeof colorClasses]} flex items-center justify-center`}>
                    <Icon className="w-5 h-5" />
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between mb-1">
                      <div>
                        <p className="text-gray-900 font-medium">{log.message}</p>
                        <p className="text-sm text-gray-600">by {log.userName}</p>
                      </div>
                      <span className="text-sm text-gray-500 whitespace-nowrap ml-4">
                        {new Date(log.timestamp).toLocaleString()}
                      </span>
                    </div>

                    <div className="flex items-center gap-2 mt-2">
                      <span className="text-xs px-2 py-1 bg-gray-100 text-gray-700 rounded">
                        {log.relatedType.toUpperCase()}
                      </span>
                      <span className="text-xs text-gray-500">ID: {log.relatedId}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-12">
            <Activity className="w-12 h-12 text-gray-400 mx-auto mb-3" />
            <p className="text-gray-500">No activities found</p>
          </div>
        )}
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
        {activityTypes.slice(1).map(type => {
          const count = logs.filter(log => log.type === type.value).length;
          const Icon = getIcon(type.value);
          const color = getColor(type.value);

          return (
            <div key={type.value} className="bg-white rounded-lg shadow p-4">
              <div className={`w-8 h-8 rounded-lg ${colorClasses[color as keyof typeof colorClasses]} flex items-center justify-center mb-2`}>
                <Icon className="w-4 h-4" />
              </div>
              <p className="text-2xl font-bold text-gray-900">{count}</p>
              <p className="text-sm text-gray-600">{type.label}</p>
            </div>
          );
        })}
      </div>
    </div>
  );
};
