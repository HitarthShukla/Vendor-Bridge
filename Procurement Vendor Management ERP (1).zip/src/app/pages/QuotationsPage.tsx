import React, { useState, useEffect, useMemo } from 'react';
import { useSearchParams, useNavigate } from 'react-router';
import { dataStore, Quotation, RFQ } from '../utils/dataStore';
import { useAuth } from '../contexts/AuthContext';
import { ArrowLeft, CheckCircle, XCircle, DollarSign, Clock, TrendingDown } from 'lucide-react';
import { toast } from 'sonner';

export const QuotationsPage: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const rfqId = searchParams.get('rfq');
  const compareRfqId = searchParams.get('compare');

  const [quotations, setQuotations] = useState<Quotation[]>(dataStore.getQuotations());
  const [selectedRfq, setSelectedRfq] = useState<RFQ | undefined>();

  useEffect(() => {
    if (rfqId) {
      setSelectedRfq(dataStore.getRFQById(rfqId));
    } else if (compareRfqId) {
      setSelectedRfq(dataStore.getRFQById(compareRfqId));
    }
  }, [rfqId, compareRfqId]);

  // Quotation Submission View (for vendors)
  if (rfqId && user?.role === 'vendor') {
    return <QuotationSubmission rfq={selectedRfq} user={user} />;
  }

  // Quotation Comparison View (for procurement officers)
  if (compareRfqId) {
    return <QuotationComparison rfq={selectedRfq} />;
  }

  // Default Quotations List View
  const userQuotations = user?.role === 'vendor'
    ? quotations.filter(q => q.vendorId === user.vendorId)
    : quotations;

  return (
    <div>
      <h1 className="text-3xl font-bold text-gray-900 mb-8">My Quotations</h1>

      <div className="space-y-4">
        {userQuotations.map((quotation) => {
          const rfq = dataStore.getRFQById(quotation.rfqId);
          const vendor = dataStore.getVendorById(quotation.vendorId);
          const total = quotation.items.reduce((sum, item) => sum + item.totalPrice, 0);

          return (
            <div key={quotation.id} className="bg-white rounded-lg shadow p-6">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">{rfq?.title}</h3>
                  <p className="text-sm text-gray-600">RFQ ID: {quotation.rfqId}</p>
                  {vendor && <p className="text-sm text-gray-600">Vendor: {vendor.name}</p>}
                </div>
                <span className={`px-3 py-1 rounded-full text-sm ${
                  quotation.status === 'accepted' ? 'bg-green-100 text-green-800' :
                  quotation.status === 'rejected' ? 'bg-red-100 text-red-800' :
                  quotation.status === 'submitted' ? 'bg-blue-100 text-blue-800' :
                  'bg-yellow-100 text-yellow-800'
                }`}>
                  {quotation.status}
                </span>
              </div>

              <div className="grid grid-cols-3 gap-4 mb-4">
                <div>
                  <p className="text-sm text-gray-600">Total Amount</p>
                  <p className="text-lg font-semibold text-gray-900">${total.toFixed(2)}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Delivery Timeline</p>
                  <p className="text-lg font-semibold text-gray-900">{quotation.deliveryTimeline}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Submitted</p>
                  <p className="text-lg font-semibold text-gray-900">
                    {quotation.submittedAt ? new Date(quotation.submittedAt).toLocaleDateString() : 'Draft'}
                  </p>
                </div>
              </div>

              {quotation.notes && (
                <div className="border-t border-gray-200 pt-4">
                  <p className="text-sm text-gray-600">Notes: {quotation.notes}</p>
                </div>
              )}
            </div>
          );
        })}

        {userQuotations.length === 0 && (
          <div className="text-center py-12 bg-white rounded-lg shadow">
            <p className="text-gray-500">No quotations found</p>
          </div>
        )}
      </div>
    </div>
  );
};

// Quotation Submission Component
const QuotationSubmission: React.FC<{ rfq?: RFQ; user: any }> = ({ rfq, user }) => {
  const navigate = useNavigate();

  // Initialize state hooks BEFORE any conditional returns
  const [quotationItems, setQuotationItems] = useState<Array<{
    rfqItemId: string;
    unitPrice: number;
    totalPrice: number;
  }>>([]);

  const [deliveryTimeline, setDeliveryTimeline] = useState('');
  const [notes, setNotes] = useState('');
  const [existingQuotationId, setExistingQuotationId] = useState<string | null>(null);

  // Initialize quotation items when RFQ loads
  useEffect(() => {
    if (!rfq) return;

    const existingQuotation = dataStore.getQuotationsByRFQ(rfq.id).find(q => q.vendorId === user.vendorId);

    if (existingQuotation) {
      // Load existing quotation
      setQuotationItems(existingQuotation.items);
      setDeliveryTimeline(existingQuotation.deliveryTimeline);
      setNotes(existingQuotation.notes || '');
      setExistingQuotationId(existingQuotation.id);
    } else {
      // Initialize new quotation items from RFQ
      setQuotationItems(rfq.items.map(item => ({
        rfqItemId: item.id,
        unitPrice: 0,
        totalPrice: 0
      })));
      setExistingQuotationId(null);
    }
  }, [rfq, user.vendorId]);

  // Now safe to return early after all hooks are called
  if (!rfq) {
    return <div>RFQ not found</div>;
  }

  const handlePriceChange = (rfqItemId: string, value: string) => {
    const unitPrice = value === '' ? 0 : parseFloat(value);

    setQuotationItems(items => items.map(item => {
      if (item.rfqItemId === rfqItemId) {
        const rfqItem = rfq.items.find(i => i.id === rfqItemId);
        const quantity = rfqItem?.quantity || 0;
        return {
          ...item,
          unitPrice: isNaN(unitPrice) ? 0 : unitPrice,
          totalPrice: isNaN(unitPrice) ? 0 : unitPrice * quantity
        };
      }
      return item;
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const quotation: Quotation = {
      id: existingQuotationId || `Q${Date.now()}`,
      rfqId: rfq.id,
      vendorId: user.vendorId,
      items: quotationItems,
      deliveryTimeline,
      notes,
      status: 'submitted',
      submittedAt: new Date().toISOString()
    };

    dataStore.saveQuotation(quotation);

    dataStore.addActivityLog({
      type: 'quotation_submitted',
      userId: user.id,
      userName: user.name,
      relatedId: quotation.id,
      relatedType: 'quotation',
      message: `Submitted quotation for RFQ: ${rfq.title}`
    });

    toast.success('Quotation submitted successfully!');
    navigate('/quotations');
  };

  const totalAmount = quotationItems.reduce((sum, item) => sum + item.totalPrice, 0);

  return (
    <div>
      <button
        onClick={() => navigate('/rfqs')}
        className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-6"
      >
        <ArrowLeft className="w-5 h-5" />
        Back to RFQs
      </button>

      <div className="bg-white rounded-lg shadow p-6 mb-6">
        <h1 className="text-2xl font-bold text-gray-900 mb-2">{rfq.title}</h1>
        <p className="text-gray-600">RFQ ID: {rfq.id}</p>
        <p className="text-gray-600">Deadline: {new Date(rfq.deadline).toLocaleDateString()}</p>
      </div>

      <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Submit Quotation</h2>

        <div className="space-y-4 mb-6">
          <div className="border border-gray-200 rounded-lg overflow-hidden">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">Item</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">Quantity</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">Unit Price ($)</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">Total ($)</th>
                </tr>
              </thead>
              <tbody>
                {rfq.items.map((rfqItem) => {
                  const quotItem = quotationItems.find(q => q.rfqItemId === rfqItem.id);
                  return (
                    <tr key={rfqItem.id} className="border-t border-gray-200">
                      <td className="px-4 py-3">
                        <div>
                          <p className="font-medium text-gray-900">{rfqItem.productService}</p>
                          <p className="text-sm text-gray-600">{rfqItem.description}</p>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-gray-900">{rfqItem.quantity} {rfqItem.unit}</td>
                      <td className="px-4 py-3">
                        <input
                          type="number"
                          step="0.01"
                          min="0"
                          required
                          value={quotItem?.unitPrice === 0 ? '' : quotItem?.unitPrice ?? ''}
                          onChange={(e) => handlePriceChange(rfqItem.id, e.target.value)}
                          className="w-32 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                          placeholder="0.00"
                        />
                      </td>
                      <td className="px-4 py-3 font-medium text-gray-900">
                        ${quotItem?.totalPrice.toFixed(2) || '0.00'}
                      </td>
                    </tr>
                  );
                })}
                <tr className="border-t-2 border-gray-300 bg-gray-50">
                  <td colSpan={3} className="px-4 py-3 text-right font-semibold text-gray-900">Total Amount:</td>
                  <td className="px-4 py-3 font-bold text-lg text-gray-900">${totalAmount.toFixed(2)}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 mb-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Delivery Timeline *
            </label>
            <input
              type="text"
              required
              value={deliveryTimeline}
              onChange={(e) => setDeliveryTimeline(e.target.value)}
              placeholder="e.g., 14 days"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg"
            />
          </div>
        </div>

        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Notes / Comments
          </label>
          <textarea
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            rows={4}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg"
            placeholder="Any additional information or terms..."
          />
        </div>

        <div className="flex gap-3">
          <button
            type="button"
            onClick={() => navigate('/rfqs')}
            className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            Submit Quotation
          </button>
        </div>
      </form>
    </div>
  );
};

// Quotation Comparison Component
const QuotationComparison: React.FC<{ rfq?: RFQ }> = ({ rfq }) => {
  const { user } = useAuth();
  const navigate = useNavigate();

  if (!rfq) {
    return <div>RFQ not found</div>;
  }

  const quotations = dataStore.getQuotationsByRFQ(rfq.id).filter(q => q.status === 'submitted');

  const quotationsWithVendors = quotations.map(q => ({
    ...q,
    vendor: dataStore.getVendorById(q.vendorId),
    total: q.items.reduce((sum, item) => sum + item.totalPrice, 0)
  }));

  const lowestPrice = Math.min(...quotationsWithVendors.map(q => q.total));

  const handleAccept = (quotation: Quotation) => {
    const updatedQuotation = { ...quotation, status: 'accepted' as const };
    dataStore.saveQuotation(updatedQuotation);

    const approval = {
      id: `A${Date.now()}`,
      quotationId: quotation.id,
      rfqId: rfq.id,
      status: 'pending' as const,
      requestedBy: user?.id || '',
      createdAt: new Date().toISOString()
    };

    dataStore.saveApproval(approval);

    dataStore.addActivityLog({
      type: 'approval_requested',
      userId: user?.id || '',
      userName: user?.name || '',
      relatedId: approval.id,
      relatedType: 'approval',
      message: `Requested approval for quotation from ${dataStore.getVendorById(quotation.vendorId)?.name}`
    });

    toast.success('Quotation accepted! Approval request created.');
    navigate('/approvals');
  };

  const handleReject = (quotation: Quotation) => {
    const updatedQuotation = { ...quotation, status: 'rejected' as const };
    dataStore.saveQuotation(updatedQuotation);
    toast.success('Quotation rejected');
    window.location.reload();
  };

  return (
    <div>
      <button
        onClick={() => navigate('/rfqs')}
        className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-6"
      >
        <ArrowLeft className="w-5 h-5" />
        Back to RFQs
      </button>

      <div className="bg-white rounded-lg shadow p-6 mb-6">
        <h1 className="text-2xl font-bold text-gray-900 mb-2">Compare Quotations</h1>
        <p className="text-gray-600">{rfq.title} - {quotations.length} quotations received</p>
      </div>

      {quotationsWithVendors.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-lg shadow">
          <p className="text-gray-500">No quotations submitted yet</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
          {quotationsWithVendors.map((quotation) => (
            <div
              key={quotation.id}
              className={`bg-white rounded-lg shadow-lg overflow-hidden ${
                quotation.total === lowestPrice ? 'ring-2 ring-green-500' : ''
              }`}
            >
              <div className={`p-4 ${quotation.total === lowestPrice ? 'bg-green-50' : 'bg-gray-50'}`}>
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-lg font-semibold text-gray-900">{quotation.vendor?.name}</h3>
                  {quotation.total === lowestPrice && (
                    <span className="flex items-center gap-1 text-green-600 text-sm font-medium">
                      <TrendingDown className="w-4 h-4" />
                      Lowest Price
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-1 text-sm text-gray-600">
                  <span>Rating:</span>
                  <span className="font-medium">{quotation.vendor?.rating || 'N/A'}</span>
                </div>
              </div>

              <div className="p-6">
                <div className="mb-4">
                  <div className="flex items-center gap-2 mb-2">
                    <DollarSign className="w-5 h-5 text-gray-400" />
                    <span className="text-sm text-gray-600">Total Amount</span>
                  </div>
                  <p className="text-3xl font-bold text-gray-900">${quotation.total.toFixed(2)}</p>
                </div>

                <div className="mb-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Clock className="w-5 h-5 text-gray-400" />
                    <span className="text-sm text-gray-600">Delivery</span>
                  </div>
                  <p className="text-lg font-medium text-gray-900">{quotation.deliveryTimeline}</p>
                </div>

                {quotation.notes && (
                  <div className="mb-4 p-3 bg-gray-50 rounded-lg">
                    <p className="text-sm text-gray-700">{quotation.notes}</p>
                  </div>
                )}

                <div className="border-t border-gray-200 pt-4 space-y-2">
                  <h4 className="font-medium text-gray-900 mb-2">Items:</h4>
                  {quotation.items.map((item) => {
                    const rfqItem = rfq.items.find(i => i.id === item.rfqItemId);
                    return (
                      <div key={item.rfqItemId} className="flex justify-between text-sm">
                        <span className="text-gray-600">{rfqItem?.productService}</span>
                        <span className="font-medium text-gray-900">${item.totalPrice.toFixed(2)}</span>
                      </div>
                    );
                  })}
                </div>

                <div className="flex gap-2 mt-6">
                  <button
                    onClick={() => handleAccept(quotation)}
                    className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
                  >
                    <CheckCircle className="w-4 h-4" />
                    Accept
                  </button>
                  <button
                    onClick={() => handleReject(quotation)}
                    className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
                  >
                    <XCircle className="w-4 h-4" />
                    Reject
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
