import React, { useState } from 'react';
import { dataStore, PurchaseOrder, Invoice } from '../utils/dataStore';
import { useAuth } from '../contexts/AuthContext';
import { FileText, Download, Printer, Mail, CheckCircle, Eye, Shield } from 'lucide-react';
import { toast } from 'sonner';
import jsPDF from 'jspdf';
import { BlockchainVerification } from '../components/BlockchainVerification';
import { BlockchainBadge } from '../components/BlockchainBadge';

export const PurchaseOrdersPage: React.FC = () => {
  const { user } = useAuth();
  const [pos, setPos] = useState<PurchaseOrder[]>(dataStore.getPurchaseOrders());
  const [selectedPO, setSelectedPO] = useState<PurchaseOrder | null>(null);
  const [showInvoiceModal, setShowInvoiceModal] = useState(false);
  const [emailTo, setEmailTo] = useState('');

  const displayPOs = user?.role === 'vendor'
    ? pos.filter(po => po.vendorId === user.vendorId)
    : pos;

  const handleGenerateInvoice = (po: PurchaseOrder) => {
    const invoice: Invoice = {
      id: `INV${Date.now()}`,
      invoiceNumber: `INV-${Date.now().toString().slice(-6)}`,
      poId: po.id,
      vendorId: po.vendorId,
      items: po.items,
      subtotal: po.subtotal,
      tax: po.tax,
      total: po.total,
      status: 'draft',
      createdAt: new Date().toISOString()
    };

    dataStore.saveInvoice(invoice);

    dataStore.addActivityLog({
      type: 'invoice_generated',
      userId: user?.id || '',
      userName: user?.name || '',
      relatedId: invoice.id,
      relatedType: 'invoice',
      message: `Generated invoice ${invoice.invoiceNumber} for PO ${po.poNumber}`
    });

    toast.success('Invoice generated successfully!');
    setSelectedPO(po);
    setShowInvoiceModal(true);
  };

  const generatePDF = (po: PurchaseOrder, invoice?: Invoice) => {
    const doc = new jsPDF();
    const vendor = dataStore.getVendorById(po.vendorId);

    doc.setFontSize(20);
    doc.text(invoice ? 'INVOICE' : 'PURCHASE ORDER', 105, 20, { align: 'center' });

    doc.setFontSize(10);
    doc.text(`${invoice ? invoice.invoiceNumber : po.poNumber}`, 105, 30, { align: 'center' });
    doc.text(`Date: ${new Date().toLocaleDateString()}`, 105, 36, { align: 'center' });

    doc.setFontSize(12);
    doc.text('From:', 20, 50);
    doc.setFontSize(10);
    doc.text('Your Company Name', 20, 56);
    doc.text('123 Business Street', 20, 62);
    doc.text('City, State 12345', 20, 68);

    doc.setFontSize(12);
    doc.text('To:', 120, 50);
    doc.setFontSize(10);
    doc.text(vendor?.name || 'N/A', 120, 56);
    doc.text(vendor?.contactPerson || '', 120, 62);
    doc.text(vendor?.address || '', 120, 68);

    doc.setFontSize(12);
    doc.text('Items:', 20, 90);

    let yPosition = 100;
    doc.setFontSize(10);
    doc.text('Item', 20, yPosition);
    doc.text('Qty', 100, yPosition);
    doc.text('Price', 130, yPosition);
    doc.text('Total', 160, yPosition);

    yPosition += 6;
    doc.line(20, yPosition, 190, yPosition);

    yPosition += 6;
    po.items.forEach((item) => {
      doc.text(item.productService, 20, yPosition);
      doc.text(item.quantity.toString(), 100, yPosition);
      doc.text(`$${item.unitPrice.toFixed(2)}`, 130, yPosition);
      doc.text(`$${item.totalPrice.toFixed(2)}`, 160, yPosition);
      yPosition += 6;
    });

    yPosition += 6;
    doc.line(20, yPosition, 190, yPosition);

    yPosition += 8;
    doc.text('Subtotal:', 130, yPosition);
    doc.text(`$${po.subtotal.toFixed(2)}`, 160, yPosition);

    yPosition += 6;
    doc.text('Tax (18%):', 130, yPosition);
    doc.text(`$${po.tax.toFixed(2)}`, 160, yPosition);

    yPosition += 6;
    doc.setFontSize(12);
    doc.text('Total:', 130, yPosition);
    doc.text(`$${po.total.toFixed(2)}`, 160, yPosition);

    if (invoice) {
      yPosition += 15;
      doc.setFontSize(10);
      doc.text('Payment Terms: Net 30 days', 20, yPosition);
      yPosition += 6;
      doc.text('Please remit payment to the above address.', 20, yPosition);
    }

    return doc;
  };

  const handleDownloadPDF = (po: PurchaseOrder, invoice?: Invoice) => {
    const doc = generatePDF(po, invoice);
    const filename = invoice ? `${invoice.invoiceNumber}.pdf` : `${po.poNumber}.pdf`;
    doc.save(filename);
    toast.success('PDF downloaded successfully!');
  };

  const handlePrintPDF = (po: PurchaseOrder, invoice?: Invoice) => {
    const doc = generatePDF(po, invoice);
    doc.autoPrint();
    window.open(doc.output('bloburl'), '_blank');
    toast.success('Opening print dialog...');
  };

  const handleSendEmail = (po: PurchaseOrder, invoice?: Invoice) => {
    if (!emailTo.trim()) {
      toast.error('Please enter an email address');
      return;
    }

    if (invoice) {
      const updatedInvoice = { ...invoice, status: 'sent' as const, sentAt: new Date().toISOString() };
      dataStore.saveInvoice(updatedInvoice);

      dataStore.addActivityLog({
        type: 'invoice_sent',
        userId: user?.id || '',
        userName: user?.name || '',
        relatedId: invoice.id,
        relatedType: 'invoice',
        message: `Sent invoice ${invoice.invoiceNumber} to ${emailTo}`
      });
    }

    toast.success(`${invoice ? 'Invoice' : 'Purchase Order'} would be sent to ${emailTo}`);
    setEmailTo('');
    setShowInvoiceModal(false);
  };

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Purchase Orders & Invoices</h1>
        <p className="text-gray-600">Manage purchase orders and generate invoices</p>
      </div>

      <div className="space-y-4">
        {displayPOs.map((po) => {
          const vendor = dataStore.getVendorById(po.vendorId);
          const invoice = dataStore.getInvoices().find(inv => inv.poId === po.id);

          return (
            <div key={po.id} className="bg-white rounded-lg shadow p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2 flex-wrap">
                    <h3 className="text-xl font-semibold text-gray-900">{po.poNumber}</h3>
                    <span className={`px-2 py-1 rounded-full text-xs ${
                      po.status === 'completed' ? 'bg-green-100 text-green-800' :
                      po.status === 'sent' ? 'bg-blue-100 text-blue-800' :
                      'bg-yellow-100 text-yellow-800'
                    }`}>
                      {po.status}
                    </span>
                    <BlockchainBadge documentId={po.id} size="sm" />
                    {invoice && (
                      <span className={`px-2 py-1 rounded-full text-xs ${
                        invoice.status === 'paid' ? 'bg-green-100 text-green-800' :
                        invoice.status === 'sent' ? 'bg-blue-100 text-blue-800' :
                        'bg-gray-100 text-gray-800'
                      }`}>
                        Invoice: {invoice.status}
                      </span>
                    )}
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                    <div>
                      <p className="text-sm text-gray-600">Vendor</p>
                      <p className="font-medium text-gray-900">{vendor?.name}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Total Amount</p>
                      <p className="text-lg font-semibold text-gray-900">${po.total.toFixed(2)}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Created</p>
                      <p className="font-medium text-gray-900">{new Date(po.createdAt).toLocaleDateString()}</p>
                    </div>
                    {invoice && (
                      <div>
                        <p className="text-sm text-gray-600">Invoice Number</p>
                        <p className="font-medium text-gray-900">{invoice.invoiceNumber}</p>
                      </div>
                    )}
                  </div>

                  <div className="border-t border-gray-200 pt-4 mb-4">
                    <h4 className="font-medium text-gray-900 mb-2">Items:</h4>
                    <div className="space-y-1">
                      {po.items.map((item, idx) => (
                        <div key={idx} className="flex justify-between text-sm">
                          <span className="text-gray-600">{item.productService} ({item.quantity}x)</span>
                          <span className="font-medium text-gray-900">${item.totalPrice.toFixed(2)}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    <button
                      onClick={() => handleDownloadPDF(po)}
                      className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
                    >
                      <Download className="w-4 h-4" />
                      Download PO
                    </button>

                    <button
                      onClick={() => handlePrintPDF(po)}
                      className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
                    >
                      <Printer className="w-4 h-4" />
                      Print PO
                    </button>

                    {!invoice && user?.role !== 'vendor' && (
                      <button
                        onClick={() => handleGenerateInvoice(po)}
                        className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                      >
                        <FileText className="w-4 h-4" />
                        Generate Invoice
                      </button>
                    )}

                    {invoice && (
                      <>
                        <button
                          onClick={() => {
                            setSelectedPO(po);
                            setShowInvoiceModal(true);
                          }}
                          className="flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700"
                        >
                          <Eye className="w-4 h-4" />
                          View Invoice
                        </button>

                        <button
                          onClick={() => handleDownloadPDF(po, invoice)}
                          className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
                        >
                          <Download className="w-4 h-4" />
                          Download Invoice
                        </button>

                        <button
                          onClick={() => handlePrintPDF(po, invoice)}
                          className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
                        >
                          <Printer className="w-4 h-4" />
                          Print Invoice
                        </button>
                      </>
                    )}
                  </div>

                  {/* Blockchain Verification */}
                  <div className="mt-6 pt-6 border-t border-gray-200">
                    <BlockchainVerification
                      documentId={po.id}
                      documentType="po"
                      documentData={po}
                    />
                  </div>
                </div>
              </div>
            </div>
          );
        })}

        {displayPOs.length === 0 && (
          <div className="text-center py-12 bg-white rounded-lg shadow">
            <p className="text-gray-500">No purchase orders found</p>
          </div>
        )}
      </div>

      {/* Invoice Modal */}
      {showInvoiceModal && selectedPO && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-3xl w-full max-h-[90vh] overflow-y-auto p-6">
            {(() => {
              const invoice = dataStore.getInvoices().find(inv => inv.poId === selectedPO.id);
              const vendor = dataStore.getVendorById(selectedPO.vendorId);

              if (!invoice) {
                return <div>Invoice not found</div>;
              }

              return (
                <>
                  <div className="border-b border-gray-200 pb-6 mb-6">
                    <h2 className="text-3xl font-bold text-center mb-2">INVOICE</h2>
                    <p className="text-center text-gray-600">{invoice.invoiceNumber}</p>
                    <p className="text-center text-sm text-gray-500">
                      Date: {new Date(invoice.createdAt).toLocaleDateString()}
                    </p>
                  </div>

                  <div className="grid grid-cols-2 gap-8 mb-8">
                    <div>
                      <h3 className="font-semibold text-gray-900 mb-2">From:</h3>
                      <p className="text-gray-700">Your Company Name</p>
                      <p className="text-gray-600">123 Business Street</p>
                      <p className="text-gray-600">City, State 12345</p>
                    </div>

                    <div>
                      <h3 className="font-semibold text-gray-900 mb-2">To:</h3>
                      <p className="text-gray-700">{vendor?.name}</p>
                      <p className="text-gray-600">{vendor?.contactPerson}</p>
                      <p className="text-gray-600">{vendor?.address}</p>
                      <p className="text-gray-600">{vendor?.email}</p>
                    </div>
                  </div>

                  <div className="mb-8">
                    <table className="w-full">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900">Item</th>
                          <th className="px-4 py-3 text-right text-sm font-semibold text-gray-900">Qty</th>
                          <th className="px-4 py-3 text-right text-sm font-semibold text-gray-900">Price</th>
                          <th className="px-4 py-3 text-right text-sm font-semibold text-gray-900">Total</th>
                        </tr>
                      </thead>
                      <tbody>
                        {invoice.items.map((item, idx) => (
                          <tr key={idx} className="border-b border-gray-200">
                            <td className="px-4 py-3 text-gray-900">{item.productService}</td>
                            <td className="px-4 py-3 text-right text-gray-900">{item.quantity}</td>
                            <td className="px-4 py-3 text-right text-gray-900">${item.unitPrice.toFixed(2)}</td>
                            <td className="px-4 py-3 text-right text-gray-900">${item.totalPrice.toFixed(2)}</td>
                          </tr>
                        ))}
                      </tbody>
                      <tfoot>
                        <tr className="border-b border-gray-200">
                          <td colSpan={3} className="px-4 py-3 text-right font-medium text-gray-900">Subtotal:</td>
                          <td className="px-4 py-3 text-right text-gray-900">${invoice.subtotal.toFixed(2)}</td>
                        </tr>
                        <tr className="border-b border-gray-200">
                          <td colSpan={3} className="px-4 py-3 text-right font-medium text-gray-900">Tax (18%):</td>
                          <td className="px-4 py-3 text-right text-gray-900">${invoice.tax.toFixed(2)}</td>
                        </tr>
                        <tr className="bg-gray-50">
                          <td colSpan={3} className="px-4 py-3 text-right font-bold text-gray-900">Total:</td>
                          <td className="px-4 py-3 text-right font-bold text-lg text-gray-900">${invoice.total.toFixed(2)}</td>
                        </tr>
                      </tfoot>
                    </table>
                  </div>

                  <div className="mb-6 p-4 bg-gray-50 rounded-lg">
                    <p className="text-sm text-gray-700">Payment Terms: Net 30 days</p>
                    <p className="text-sm text-gray-700">Please remit payment to the above address.</p>
                  </div>

                  <div className="mb-6">
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Send Invoice via Email
                    </label>
                    <input
                      type="email"
                      value={emailTo}
                      onChange={(e) => setEmailTo(e.target.value)}
                      placeholder={vendor?.email || 'vendor@example.com'}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                    />
                  </div>

                  <div className="flex gap-3">
                    <button
                      onClick={() => {
                        setShowInvoiceModal(false);
                        setSelectedPO(null);
                        setEmailTo('');
                      }}
                      className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
                    >
                      Close
                    </button>
                    <button
                      onClick={() => handleSendEmail(selectedPO, invoice)}
                      className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                    >
                      <Mail className="w-4 h-4" />
                      Send Email
                    </button>
                  </div>
                </>
              );
            })()}
          </div>
        </div>
      )}
    </div>
  );
};
