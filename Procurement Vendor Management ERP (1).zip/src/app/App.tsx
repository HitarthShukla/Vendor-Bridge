import React, { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router';
import { AuthProvider } from './contexts/AuthContext';
import { ProtectedRoute } from './components/ProtectedRoute';
import { Layout } from './components/Layout';
import { LoginPage } from './pages/LoginPage';
import { DashboardPage } from './pages/DashboardPage';
import { VendorsPage } from './pages/VendorsPage';
import { RFQsPage } from './pages/RFQsPage';
import { QuotationsPage } from './pages/QuotationsPage';
import { ApprovalsPage } from './pages/ApprovalsPage';
import { PurchaseOrdersPage } from './pages/PurchaseOrdersPage';
import { ActivityLogsPage } from './pages/ActivityLogsPage';
import { ReportsPage } from './pages/ReportsPage';
import { dataStore } from './utils/dataStore';
import { Toaster } from 'sonner';
import { AIChatbot } from './components/AIChatbot';

export default function App() {
  useEffect(() => {
    dataStore.initializeDemoData();

    const users = JSON.parse(localStorage.getItem('users') || '[]');
    if (users.length === 0) {
      const demoUsers = [
        { id: '1', email: 'officer@demo.com', password: 'demo123', name: 'John Officer', role: 'procurement_officer' },
        { id: '2', email: 'vendor@demo.com', password: 'demo123', name: 'Jane Vendor', role: 'vendor', vendorId: 'V001' },
        { id: '3', email: 'manager@demo.com', password: 'demo123', name: 'Mike Manager', role: 'manager' },
        { id: '4', email: 'admin@demo.com', password: 'demo123', name: 'Alice Admin', role: 'admin' },
      ];
      localStorage.setItem('users', JSON.stringify(demoUsers));
    }
  }, []);

  return (
    <AuthProvider>
      <BrowserRouter>
        <Toaster position="top-right" richColors />
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route
            path="/dashboard"
            element={
              <ProtectedRoute>
                <Layout>
                  <DashboardPage />
                </Layout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/vendors"
            element={
              <ProtectedRoute>
                <Layout>
                  <VendorsPage />
                </Layout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/rfqs"
            element={
              <ProtectedRoute>
                <Layout>
                  <RFQsPage />
                </Layout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/quotations"
            element={
              <ProtectedRoute>
                <Layout>
                  <QuotationsPage />
                </Layout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/approvals"
            element={
              <ProtectedRoute>
                <Layout>
                  <ApprovalsPage />
                </Layout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/purchase-orders"
            element={
              <ProtectedRoute>
                <Layout>
                  <PurchaseOrdersPage />
                </Layout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/activity"
            element={
              <ProtectedRoute>
                <Layout>
                  <ActivityLogsPage />
                </Layout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/reports"
            element={
              <ProtectedRoute>
                <Layout>
                  <ReportsPage />
                </Layout>
              </ProtectedRoute>
            }
          />
          <Route path="/" element={<Navigate to="/dashboard" replace />} />
        </Routes>
        {/* AI Chatbot - Available on all pages */}
        <AIChatbot />
      </BrowserRouter>
    </AuthProvider>
  );
}