# Quick Backend Setup Guide

## Why No Backend Files?

This **Figma Make environment is frontend-only** (React/TypeScript). The backend must be created in a **separate Node.js environment**.

---

## ✅ What You Have (Specifications)

```
/workspaces/default/code/backend/
├── package.json               ✅ Dependencies list
├── tsconfig.json             ✅ TypeScript config
├── .env.example              ✅ Environment template
├── README.md                 ✅ API documentation
├── database/schema.sql       ✅ PostgreSQL schema
└── .gitignore               ✅ Git ignore rules
```

---

## ❌ What You Need to Create (Code)

All the actual TypeScript code files need to be created in a **separate Node.js project**.

---

## 🚀 Two Options

### Option 1: Copy-Paste Ready Code (Easiest)

**See:** `/workspaces/default/code/COMPLETE_BACKEND_CODE.md`

This file contains ALL the backend code ready to copy-paste:
- ✅ `database/db.ts` - Database connection
- ✅ `middleware/auth.ts` - JWT authentication
- ✅ `routes/auth.ts` - Login/signup
- ✅ `routes/vendors.ts` - Vendor CRUD
- ✅ `server.ts` - Express server

**Steps:**
1. Create a new Node.js project outside this workspace
2. Copy the code from `COMPLETE_BACKEND_CODE.md`
3. Create files and paste the code
4. Install dependencies: `npm install`
5. Run: `npm run dev`

### Option 2: Follow Specifications (Learn by Doing)

**See:** `/workspaces/default/code/BACKEND_IMPLEMENTATION_GUIDE.md`

This file contains:
- SQL query patterns
- API endpoint specifications
- Implementation examples

**Steps:**
1. Read the specifications
2. Implement each route following the SQL patterns
3. Test with Postman or curl

---

## 📋 Complete Setup Checklist

### 1. Create Separate Node.js Project

```bash
# Outside Figma Make workspace
cd ~
mkdir procurement-erp-backend
cd procurement-erp-backend
```

### 2. Copy Specification Files

From `/workspaces/default/code/backend/`:
```bash
# Copy these files to your new project
cp /workspaces/default/code/backend/package.json .
cp /workspaces/default/code/backend/tsconfig.json .
cp /workspaces/default/code/backend/.env.example .env
cp -r /workspaces/default/code/backend/database .
```

### 3. Create Code Files

Either:
- **Option A:** Copy from `COMPLETE_BACKEND_CODE.md`
- **Option B:** Implement following `BACKEND_IMPLEMENTATION_GUIDE.md`

Required files:
```
backend/
├── server.ts
├── database/
│   └── db.ts
├── middleware/
│   └── auth.ts
└── routes/
    ├── auth.ts
    ├── vendors.ts
    ├── rfqs.ts
    ├── quotations.ts
    ├── approvals.ts
    ├── purchaseOrders.ts
    ├── invoices.ts
    ├── activityLogs.ts
    └── analytics.ts
```

### 4. Install Dependencies

```bash
npm install
```

Expected packages:
- express
- pg (PostgreSQL)
- bcryptjs
- jsonwebtoken
- cors
- dotenv
- nodemailer
- typescript (dev)
- @types/* (dev)

### 5. Setup PostgreSQL

```bash
# Create database
createdb procurement_erp

# Run schema
psql -d procurement_erp -f database/schema.sql

# Verify
psql -d procurement_erp -c "\dt"
```

### 6. Configure Environment

Edit `.env`:
```env
PORT=5000
DB_HOST=localhost
DB_PORT=5432
DB_NAME=procurement_erp
DB_USER=postgres
DB_PASSWORD=your_password
JWT_SECRET=your-super-secret-key
```

### 7. Generate Password Hash

```bash
node -e "const bcrypt = require('bcryptjs'); bcrypt.hash('demo123', 10, (e,h) => console.log(h));"
```

Update `database/schema.sql` with the hash.

### 8. Start Backend

```bash
# Development mode
npm run dev

# Should see:
# ✓ Database connection established
# 🚀 Server running on: http://localhost:5000
```

### 9. Test API

```bash
# Health check
curl http://localhost:5000/health

# Login
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"officer@demo.com","password":"demo123"}'
```

### 10. Connect Frontend

Update frontend to call backend instead of localStorage.

---

## 📁 File Locations

| What | Where |
|------|-------|
| Backend Specifications | `/workspaces/default/code/backend/` |
| Complete Code | `/workspaces/default/code/COMPLETE_BACKEND_CODE.md` |
| Implementation Guide | `/workspaces/default/code/BACKEND_IMPLEMENTATION_GUIDE.md` |
| Setup Instructions | `/workspaces/default/code/SETUP_INSTRUCTIONS.md` |
| This Guide | `/workspaces/default/code/QUICK_BACKEND_SETUP.md` |

---

## 🎯 Summary

**Problem:** Figma Make environment blocks backend `.ts` files

**Solution:** Create backend in separate Node.js project

**What You Have:**
- ✅ Complete specifications
- ✅ Database schema (SQL)
- ✅ API documentation
- ✅ Ready-to-copy code

**What You Need to Do:**
1. Create new Node.js project
2. Copy specifications
3. Copy code from `COMPLETE_BACKEND_CODE.md`
4. Setup PostgreSQL
5. Run backend
6. Connect frontend

---

## ⚡ Ultra Quick Start

```bash
# 1. New project
mkdir ~/procurement-backend && cd ~/procurement-backend

# 2. Copy specs from /workspaces/default/code/backend/

# 3. Copy code from COMPLETE_BACKEND_CODE.md

# 4. Install
npm install

# 5. Database
createdb procurement_erp
psql -d procurement_erp -f database/schema.sql

# 6. Configure .env

# 7. Run
npm run dev

# 8. Test
curl http://localhost:5000/health
```

---

## 🆘 Need Help?

**All documentation is in:**
- `COMPLETE_BACKEND_CODE.md` - Full code
- `BACKEND_IMPLEMENTATION_GUIDE.md` - SQL patterns
- `backend/README.md` - API docs
- `backend/database/schema.sql` - Database schema
- `SETUP_INSTRUCTIONS.md` - Detailed setup

**Everything is ready - you just need to copy it to a Node.js environment!** 🚀
