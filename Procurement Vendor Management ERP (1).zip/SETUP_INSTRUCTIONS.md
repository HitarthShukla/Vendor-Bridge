# Complete Setup Instructions

## Quick Start Guide

### Step 1: Install PostgreSQL

**On macOS:**
```bash
brew install postgresql@14
brew services start postgresql@14
```

**On Ubuntu/Debian:**
```bash
sudo apt update
sudo apt install postgresql postgresql-contrib
sudo systemctl start postgresql
```

**On Windows:**
Download and install from https://www.postgresql.org/download/windows/

### Step 2: Create Database

```bash
# Connect to PostgreSQL (default user is 'postgres')
psql -U postgres

# Inside psql, create database
CREATE DATABASE procurement_erp;

# Exit psql
\q
```

### Step 3: Generate Password Hash

The demo users need bcrypt-hashed passwords. Generate the hash:

```bash
cd backend
npm install
node scripts/hashPassword.js
```

Copy the generated hash and update `backend/database/schema.sql` lines 88-91, replacing `$2a$10$YourHashedPasswordHere` with the actual hash.

### Step 4: Run Database Schema

```bash
psql -U postgres -d procurement_erp -f backend/database/schema.sql
```

You should see:
```
CREATE TABLE
CREATE TABLE
...
INSERT 0 4  (users created)
INSERT 0 4  (vendors created)
```

### Step 5: Configure Backend

```bash
cd backend
cp .env.example .env
```

Edit `.env` with your PostgreSQL credentials:

```env
PORT=5000
NODE_ENV=development

DB_HOST=localhost
DB_PORT=5432
DB_NAME=procurement_erp
DB_USER=postgres
DB_PASSWORD=your_postgres_password

JWT_SECRET=your-super-secret-jwt-key-change-this-in-production
```

### Step 6: Install Backend Dependencies

```bash
cd backend
npm install
```

Expected packages:
- express
- pg (PostgreSQL client)
- bcryptjs
- jsonwebtoken
- cors
- dotenv
- nodemailer

### Step 7: Start Backend Server

```bash
npm run dev
```

You should see:
```
✓ Connected to PostgreSQL database
========================================
🚀 Procurement ERP Backend Server
========================================
Server running on: http://localhost:5000
========================================
```

Test the backend:
```bash
curl http://localhost:5000/health
```

Expected response:
```json
{
  "status": "OK",
  "message": "Procurement ERP API is running",
  "timestamp": "2026-06-06T..."
}
```

### Step 8: Test Database Connection

Try logging in with a demo account:

```bash
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"officer@demo.com","password":"demo123"}'
```

Expected response:
```json
{
  "message": "Login successful",
  "token": "eyJhbGciOiJIUzI1NiIs...",
  "user": {
    "id": 1,
    "email": "officer@demo.com",
    "name": "John Officer",
    "role": "procurement_officer"
  }
}
```

### Step 9: Update Frontend to Use Backend API

The current frontend uses localStorage. You need to create an API client to connect to the backend.

Create `src/app/utils/api.ts`:

```typescript
const API_BASE_URL = 'http://localhost:5000/api';

export const api = {
  async request(endpoint: string, options: RequestInit = {}) {
    const token = localStorage.getItem('token');
    
    const headers: HeadersInit = {
      'Content-Type': 'application/json',
      ...(token && { Authorization: `Bearer ${token}` }),
      ...options.headers,
    };

    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      ...options,
      headers,
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'API request failed');
    }

    return response.json();
  },

  // Auth
  login: (email: string, password: string) =>
    api.request('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    }),

  signup: (email: string, password: string, name: string, role: string) =>
    api.request('/auth/signup', {
      method: 'POST',
      body: JSON.stringify({ email, password, name, role }),
    }),

  // Vendors
  getVendors: () => api.request('/vendors'),
  createVendor: (vendor: any) =>
    api.request('/vendors', {
      method: 'POST',
      body: JSON.stringify(vendor),
    }),

  // RFQs
  getRFQs: () => api.request('/rfqs'),
  createRFQ: (rfq: any) =>
    api.request('/rfqs', {
      method: 'POST',
      body: JSON.stringify(rfq),
    }),

  // ... add other endpoints as needed
};
```

### Step 10: Install Frontend Dependencies

```bash
cd ..  # back to root directory
pnpm install
```

### Step 11: Start Frontend Development Server

```bash
pnpm run dev
```

The frontend should start on the configured port.

### Step 12: Test the Application

1. Open browser to frontend URL
2. Login with demo account: `officer@demo.com` / `demo123`
3. Create a new RFQ
4. Switch to vendor account: `vendor@demo.com` / `demo123`
5. Submit a quotation
6. Switch back to officer account
7. Accept the quotation
8. Switch to manager account: `manager@demo.com` / `demo123`
9. Approve the request
10. View the generated Purchase Order
11. Generate and download Invoice

## Troubleshooting

### Database Connection Issues

**Error: "password authentication failed"**
```bash
# Check PostgreSQL is running
pg_isready

# Reset postgres password
sudo -u postgres psql
ALTER USER postgres PASSWORD 'newpassword';
```

**Error: "database does not exist"**
```bash
createdb -U postgres procurement_erp
```

### Backend Issues

**Error: "Cannot find module 'express'"**
```bash
cd backend
rm -rf node_modules package-lock.json
npm install
```

**Error: "Port 5000 already in use"**
```bash
# Change PORT in backend/.env
PORT=5001
```

### Frontend Issues

**Error: "Failed to fetch"**
- Check backend is running on http://localhost:5000
- Check CORS is enabled in backend
- Verify API_BASE_URL in frontend matches backend port

## Database Verification

Verify tables were created:

```bash
psql -U postgres -d procurement_erp

\dt  # List all tables
```

You should see:
```
 public | activity_logs        | table | postgres
 public | approval_workflows   | table | postgres
 public | invoice_items        | table | postgres
 public | invoices             | table | postgres
 public | purchase_order_items | table | postgres
 public | purchase_orders      | table | postgres
 public | quotation_items      | table | postgres
 public | quotations           | table | postgres
 public | rfq_items            | table | postgres
 public | rfq_vendors          | table | postgres
 public | rfqs                 | table | postgres
 public | users                | table | postgres
 public | vendors              | table | postgres
```

Check demo data:

```sql
SELECT id, email, name, role FROM users;
SELECT id, name, category, status FROM vendors;
```

## API Testing with curl

### Create RFQ
```bash
# First, login and get token
TOKEN=$(curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"officer@demo.com","password":"demo123"}' \
  | jq -r '.token')

# Create RFQ
curl -X POST http://localhost:5000/api/rfqs \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Office Supplies Q2 2026",
    "deadline": "2026-07-01",
    "items": [
      {
        "productService": "Printer Paper",
        "description": "A4 size, 80 GSM",
        "quantity": 100,
        "unit": "reams"
      }
    ],
    "assignedVendors": [1, 2]
  }'
```

### Get Vendors
```bash
curl http://localhost:5000/api/vendors \
  -H "Authorization: Bearer $TOKEN"
```

## Production Deployment

### Backend
1. Set up PostgreSQL on production server
2. Update `.env` with production database credentials
3. Set `NODE_ENV=production`
4. Use a process manager (PM2):
   ```bash
   npm install -g pm2
   pm2 start server.js --name procurement-api
   ```

### Frontend
1. Build production bundle:
   ```bash
   pnpm build
   ```
2. Deploy to static hosting (Netlify, Vercel, S3, etc.)
3. Update API_BASE_URL to production backend URL

### Security Checklist
- [ ] Change JWT_SECRET to a strong random value
- [ ] Enable SSL/TLS (HTTPS)
- [ ] Set up database backups
- [ ] Configure firewall rules
- [ ] Enable rate limiting
- [ ] Set up monitoring and logging
- [ ] Configure CORS for production domain only
- [ ] Use environment variables for all sensitive data

## Next Steps

1. Replace all localStorage calls in frontend with API calls
2. Implement proper error handling in frontend
3. Add loading states for API requests
4. Implement retry logic for failed requests
5. Add request caching where appropriate
6. Set up automated testing
7. Configure CI/CD pipeline

## Support

If you encounter issues:
1. Check logs: `tail -f backend/server.log`
2. Verify database: `psql -U postgres -d procurement_erp`
3. Test API endpoints with curl
4. Check browser console for frontend errors
